package project.okami.tools;

import java.util.Hashtable;
import java.util.List;

public class Constants {

	public static final String PS2_PLATFORM_NAME = "PS2";

	public static final String WII_PLATFORM_NAME = "WII";

	public static final int LINES_PER_SENTENCE = 2;

	public static final int N_LINE_LENGTH_DEFAULT = 74;

	public static final String EXTENSION_TEXT = ".txt";

	public static final String EXTENSION_HELPER_TEXT = ".resources";

	public static final String EXTENSION_EXPORT = ".export";

	public static final String SYMBOL_TRANSLATE_HELPER_TEXT = "=";

	public static final String SUFFIX_PS2_FILE_NAME_SPANISH_TEXT = "_ps2_resultado";

	public static final String SUFFIX_WII_FILE_NAME_SPANISH_TEXT = "_wii_resultado";

	public static final String SUFFIX_FILE_NAME_INTER_TEXT = "_intermediate";

	// Constantes que identifican los par�metros de configuraci�n

	public static final String MARK_FINISH_PARAGRAPH = "[/P";

	public static final String MARK_INIT_HEADER = "[H]";

	public static final String MARK_FINISH_HEADER = "[/H]";

	public static final String MARK_INIT_TEXT_TO_TRANSLETE = "[TT]";

	public static final String MARK_FINISH_TEXT_TO_TRANSLETE = "[/TT]";

	public static final String MARK_CARRY_RETURN = "[CR]";

	public static final String MARK_USER_PULSE_PLEASE = "[NPP]";

	public static final String MARK_NO_NEED_USER_PULSE_PLEASE = "[!NPP]";

	public static final String MARK_INIT_RED_TEXT = "[RT]";

	public static final String MARK_FINISH_RED_TEXT = "[/RT]";

	public static final String MARK_INIT_SMALL_TEXT = "[ST]";

	public static final String MARK_FINISH_SMALL_TEXT = "[/ST]";

	public static final String MARK_INIT_BIG_TEXT = "[BT]";

	public static final String MARK_FINISH_BIG_TEXT = "[/BT]";

	public static final String MARK_NO_SPACING_IN_PREVIOUS_TEXT = "[<-NS]";

	public static final String MARK_OPTION_TEXT_QUESTION = "[OTQ]";

	public static final String MARK_OPTION_TEXT_DEFAULT = "[OTD]";

	public static final String MARK_OPTION_TEXT = "[OT]";

	public static final String SYMBOL_USER_PULSE_PLEASE = "symbol.user.pulse.please";

	public static final String SYMBOL_NO_NEED_USER_PULSE_PLEASE = "symbol.no.need.user.pulse.please";

	public static final String SYMBOL_SEPARATOR_PARAGRAPH = "symbol.separator.paragraph";

	public static final String SYMBOL_CARRY_RETURN = "symbol.carry.return";

	public static final String SYMBOL_END_SENTENCE = "symbol.end.sentence";

	public static final String SYMBOL_PREFFIX_RED_TEXT = "symbol.preffix.red.text";

	public static final String SYMBOL_SUFFIX_RED_TEXT = "symbol.suffix.red.text";

	public static final String SYMBOL_PREFFIX_SMALL_TEXT = "symbol.preffix.small.text";

	public static final String SYMBOL_SUFFIX_SMALL_TEXT = "symbol.suffix.small.text";

	public static final double DIFF_SMALL_TEXT = 0.75;

	public static final String SYMBOL_PREFFIX_BIG_TEXT = "symbol.preffix.big.text";

	public static final String SYMBOL_SUFFIX_BIG_TEXT = "symbol.suffix.big.text";

	public static final double DIFF_BIG_TEXT = 1.25;

	public static final String SYMBOL_PREFFIX_EXCLAMATION = "[";

	public static final String SYMBOL_SUFFIX_EXCLAMATION = "]";

	public static final String SYMBOL_OPTION_TEXT_QUESTION = "symbol.option.text.question";

	public static final String SYMBOL_OPTION_TEXT_DEFAULT = "symbol.option.text.default";

	public static final String SYMBOL_OPTION_TEXT = "symbol.option.text";

	public static Hashtable<String, String> config_ps2;

	public static Hashtable<String, String> config_wii;

	public static List<String[]> exclamations;

	public static final String PATH_EXCEL = "E:\\workpath\\SVN\\PS2\\excel\\TraduccionOkami.xls";

	public static final String PATH_TRANSLATES_TEXT = "E:\\workpath\\SVN\\PS2\\text";

	public static final String PATH_ORIGINAL_BIN_FILES = "E:\\workpath\\SVN\\PS2\\extractTranslate\\originalFiles\\frances";

	public static final String PATH_TRANSLATE_BIN_FILES = "E:\\workpath\\SVN\\PS2\\extractTranslate";

	public static final int ROW_INIT_DATA = 3;

	public static final String BUILD_PATH = "E:\\workpath\\SVN\\PS2\\automatic\\";

}
