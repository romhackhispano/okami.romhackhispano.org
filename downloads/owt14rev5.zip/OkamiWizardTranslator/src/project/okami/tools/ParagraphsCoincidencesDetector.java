package project.okami.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParagraphsCoincidencesDetector {

	/**
	 * M�todo principal.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(
				System.in));

		FileInputStream fInputStreamOriginalNoTranslate = null;
		FileInputStream fInputStreamOriginalTranslate = null;
		FileInputStream fInputStreamDestinyNoTranslate = null;
		FileOutputStream fOutputStreamDestinyTranslate = null;
		Map<String, String> mParagraphsOriginal = null;
		try {
			System.out
					.println("Introduzca la ruta y el fichero base no traducido:");
			fInputStreamOriginalNoTranslate = new FileInputStream(new File(
					teclado.readLine()));
			System.out
					.println("Introduzca la ruta y el fichero base traducido:");
			fInputStreamOriginalTranslate = new FileInputStream(new File(
					teclado.readLine()));
			System.out.println("Creando el mapeado de p�rrafos...");
			mParagraphsOriginal = new HashMap<String, String>();
			char cCurrentChar;
			String sCurrentParagraph = "";

			List<String> lParagraphNoTranslate = new ArrayList<String>();
			while (fInputStreamOriginalNoTranslate.available() > 0) {
				cCurrentChar = (char) fInputStreamOriginalNoTranslate.read();
				sCurrentParagraph += cCurrentChar;
				if (sCurrentParagraph.endsWith(".�")) {
					lParagraphNoTranslate.add(sCurrentParagraph);
					sCurrentParagraph = "";
				}
			}

			List<String> lParagraphTranslate = new ArrayList<String>();
			while (fInputStreamOriginalTranslate.available() > 0) {
				cCurrentChar = (char) fInputStreamOriginalTranslate.read();
				sCurrentParagraph += cCurrentChar;
				if (sCurrentParagraph.endsWith(".�")) {
					lParagraphTranslate.add(sCurrentParagraph);
					sCurrentParagraph = "";
				}
			}

			if (lParagraphNoTranslate.size() == lParagraphTranslate.size()) {
				for (int i = 0; i < lParagraphNoTranslate.size(); i++)
					mParagraphsOriginal.put(lParagraphNoTranslate.get(i),
							lParagraphTranslate.get(i));
			}
			System.out.println("-- Mapeado finalizado ["
					+ lParagraphNoTranslate.size() + " p�rrafos] --");

			System.out
					.println("Introduzca la ruta y el fichero objetivo no traducido:");
			fInputStreamDestinyNoTranslate = new FileInputStream(new File(
					teclado.readLine()));
			List<String> lParagraphs = new ArrayList<String>();
			while (fInputStreamDestinyNoTranslate.available() > 0) {
				cCurrentChar = (char) fInputStreamDestinyNoTranslate.read();
				sCurrentParagraph += cCurrentChar;
				if (sCurrentParagraph.endsWith(".�")) {
					lParagraphs.add(sCurrentParagraph);
					sCurrentParagraph = "";
				}
			}
			System.out.println("El fichero objetivo tiene "
					+ lParagraphs.size() + " p�rrafos.");
			System.out
					.println("Introduzca la ruta y el fichero objetivo no traducido que contendr� las coincidencias:");
			fOutputStreamDestinyTranslate = new FileOutputStream(new File(
					teclado.readLine()));

			System.out.println("Detectando coincidencias...");
			String sTextFound = null;
			int nCoincidentes = 0;
			for (int i = 0; i < lParagraphs.size(); i++) {
				sTextFound = mParagraphsOriginal.get(lParagraphs.get(i));
				if (sTextFound == null || sTextFound.equals("")) {
					sTextFound = lParagraphs.get(i);
					System.out.println("P�rrafo " + (i + 1) + " :( ||"
							+ sTextFound);
				} else {
					nCoincidentes++;
					System.out.println("P�rrafo " + (i + 1) + " :) ||"
							+ sTextFound);
				}
				for (int nChar = 0; nChar < sTextFound.length(); nChar++) {
					fOutputStreamDestinyTranslate.write(sTextFound
							.charAt(nChar));
				}
			}
			System.out.println(nCoincidentes + " p�rrafos coincidentes.");

		} catch (FileNotFoundException fnfe) {
			System.exit(0);
		} catch (IOException ioe) {
			System.exit(0);
		} finally {
			try {
				if (fInputStreamOriginalNoTranslate != null)
					fInputStreamOriginalNoTranslate.close();
				if (fInputStreamOriginalTranslate != null)
					fInputStreamOriginalTranslate.close();
				if (fInputStreamDestinyNoTranslate != null)
					fInputStreamDestinyNoTranslate.close();
				if (fOutputStreamDestinyTranslate != null)
					fOutputStreamDestinyTranslate.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}

	}

}
