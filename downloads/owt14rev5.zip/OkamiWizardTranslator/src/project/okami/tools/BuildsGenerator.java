package project.okami.tools;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class BuildsGenerator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out
				.println("_______________________________ GENERADOR DE BUILDS _______________________________\n");

		String sExcelPath = null;
		String sPathOriginalFiles = null;
		String sPathTranslateFiles = null;
		String sBuildPath = null;
		String sPathTranslateTextFiles = null;
		PrintStream psBuildAll = null;
		String sPlatform = null;
		POIFSFileSystem fs = null;

		BufferedReader keyboard = new BufferedReader(new InputStreamReader(
				System.in));

		try {

			boolean bOptionCorrect = false;
			while (!bOptionCorrect) {
				System.out
						.println("Introduzca la plataforma para la que quiere generar los builds ("
								+ Constants.PS2_PLATFORM_NAME
								+ "\\"
								+ Constants.WII_PLATFORM_NAME + "):");
				sPlatform = keyboard.readLine();
				if (sPlatform.equals(Constants.PS2_PLATFORM_NAME)
						|| sPlatform.equals(Constants.WII_PLATFORM_NAME)) {
					bOptionCorrect = true;
				} else {
					System.err.println("ERROR: Los formatos posibles son "
							+ Constants.PS2_PLATFORM_NAME + " o "
							+ Constants.WII_PLATFORM_NAME + ".");
				}
			}

			System.out
					.println("Introduzca la ruta y nombre de la excel con los datos:");
			sExcelPath = keyboard.readLine();

			System.out
					.println("Introduzca la ruta donde estan los archivos originales en frances:");
			sPathOriginalFiles = keyboard.readLine();

			System.out
					.println("Introduzca la ruta donde estan los archivos traducidos en espa�ol:");
			sPathTranslateFiles = keyboard.readLine();

			System.out
					.println("Introduzca la ruta donde se encuentran las aplicaciones de regeneraci�n:");
			sBuildPath = keyboard.readLine();

			System.out
					.println("Introduzca la ruta donde se encuentran los textos traducidos:");
			sPathTranslateTextFiles = keyboard.readLine();

			try {

				File fBuildAllOutput = new File(sPathTranslateTextFiles,
						"rebuildAll.bat");
				if (fBuildAllOutput.exists())
					fBuildAllOutput.delete();

				psBuildAll = new PrintStream(new BufferedOutputStream(
						new FileOutputStream(fBuildAllOutput)));

				fs = new POIFSFileSystem(new FileInputStream(sExcelPath));

				HSSFWorkbook wb = new HSSFWorkbook(fs);
				HSSFFormulaEvaluator hssffe = new HSSFFormulaEvaluator(wb);
				HSSFSheet sheet = wb.getSheetAt(0);

				int iNumRows = sheet.getLastRowNum();

				HSSFRow hssfCurrentRow;
				for (int iCurrentRow = Constants.ROW_INIT_DATA; iCurrentRow < iNumRows; iCurrentRow++) {
					hssfCurrentRow = sheet.getRow(iCurrentRow);
					if (hssfCurrentRow.getCell(32) != null
							&& !""
									.equals(hssfCurrentRow.getCell(32)
											.toString())) {
						String origen = sPathOriginalFiles
								+ hssfCurrentRow.getCell(32).toString();
						String destino = sPathTranslateFiles
								+ hssfCurrentRow.getCell(32).toString();

						String extractPostInstructionsParam1 = Integer
								.toString(hex2decimal(hssfCurrentRow
										.getCell((sPlatform
												.equals(Constants.PS2_PLATFORM_NAME)) ? 11
														: 10).toString()));
						String extractPostInstructionsParam2 = Integer
								.toString(hex2decimal(hssfCurrentRow
										.getCell((sPlatform
												.equals(Constants.PS2_PLATFORM_NAME)) ? 14
														: 13).toString())
										- hex2decimal(hssfCurrentRow
												.getCell((sPlatform
														.equals(Constants.PS2_PLATFORM_NAME)) ? 11
																: 10).toString()));

						String insertPostInstructionsFrancesParam = Integer
								.toString(hex2decimal(hssfCurrentRow
										.getCell(12).toString()));

						String insertMargenFrancesParam1 = Integer
								.toString(hex2decimal(hssfCurrentRow
										.getCell(12).toString())
										+ (hex2decimal(hssfCurrentRow.getCell((sPlatform
												.equals(Constants.PS2_PLATFORM_NAME)) ? 14
														: 13).toString()) - hex2decimal(hssfCurrentRow
												.getCell((sPlatform
														.equals(Constants.PS2_PLATFORM_NAME)) ? 11
																: 10).toString())));
						String insertMargenFrancesParam2 = "0";
						String insertMargenFrancesParam3 = Integer
								.toString(hex2decimal(hssfCurrentRow
										.getCell((sPlatform
												.equals(Constants.PS2_PLATFORM_NAME)) ? 16
														: 15).toString())
										- (hex2decimal(hssfCurrentRow.getCell(
												12).toString()) + (hex2decimal(hssfCurrentRow
												.getCell((sPlatform
														.equals(Constants.PS2_PLATFORM_NAME)) ? 14
																: 13).toString()) - hex2decimal(hssfCurrentRow
												.getCell((sPlatform
														.equals(Constants.PS2_PLATFORM_NAME)) ? 11
																: 10).toString()))));

						String recalculatePointersParam1 = "";
						int evaluatedCellType = hssffe
								.evaluateFormulaCell(hssfCurrentRow.getCell(28));
						if (evaluatedCellType == HSSFCell.CELL_TYPE_STRING)
							recalculatePointersParam1 = hssfCurrentRow.getCell(
									28).getRichStringCellValue().getString();
						else if (evaluatedCellType == HSSFCell.CELL_TYPE_NUMERIC)
							recalculatePointersParam1 += new Double(
									hssfCurrentRow.getCell(28)
											.getNumericCellValue()).intValue();

						String recalculatePointersParam2 = "";
						evaluatedCellType = hssffe
								.evaluateFormulaCell(hssfCurrentRow.getCell(29));
						if (evaluatedCellType == HSSFCell.CELL_TYPE_STRING)
							recalculatePointersParam2 = hssfCurrentRow.getCell(
									29).getRichStringCellValue().getString();
						else if (evaluatedCellType == HSSFCell.CELL_TYPE_NUMERIC)
							recalculatePointersParam2 += new Double(
									hssfCurrentRow.getCell(29)
											.getNumericCellValue()).intValue();

						String recalculatePointersParam3 = "";
						evaluatedCellType = hssffe
								.evaluateFormulaCell(hssfCurrentRow.getCell(30));
						if (evaluatedCellType == HSSFCell.CELL_TYPE_STRING)
							recalculatePointersParam3 = hssfCurrentRow.getCell(
									30).getRichStringCellValue().getString();
						else if (evaluatedCellType == HSSFCell.CELL_TYPE_NUMERIC)
							recalculatePointersParam3 += new Double(
									hssfCurrentRow.getCell(30)
											.getNumericCellValue()).intValue();

						String recalculatePointersParam4 = "4";

						// La combinaci�n de caracteres que indican el fin de
						// p�rrafo difiere en cada plataforma
						String recalculatePointersParam5 = (sPlatform
								.equals(Constants.PS2_PLATFORM_NAME)) ? "01"
								: "80";
						String recalculatePointersParam6 = (sPlatform
								.equals(Constants.PS2_PLATFORM_NAME)) ? "80"
								: "01";

						// Composicion del built.bat
						String situatedBuildPathLine = "cd " + sBuildPath;
						String copyOriginLine = "copy /Y " + origen + " origen";
						String copyDestinyLine = "copy /Y " + destino
								+ " destino";
						String extractPostInstructionsLine = "extractb origen post "
								+ extractPostInstructionsParam1
								+ " "
								+ extractPostInstructionsParam2;
						String insertPostInstructionsFrancesLine = "insertb post destino "
								+ insertPostInstructionsFrancesParam;
						String insertMargenFrancesLine = "insertb margen destino "
								+ insertMargenFrancesParam1
								+ " "
								+ insertMargenFrancesParam2
								+ " "
								+ insertMargenFrancesParam3;
						String deletePostLine = "del post";
						String recalculatePointersLine = ((sPlatform
								.equals(Constants.PS2_PLATFORM_NAME)) ? "vrecalc.exe"
								: "vrecalcwii.exe")
								+ " destino "
								+ recalculatePointersParam1
								+ " "
								+ recalculatePointersParam2
								+ " "
								+ recalculatePointersParam3
								+ " "
								+ recalculatePointersParam4
								+ " "
								+ recalculatePointersParam5
								+ " "
								+ recalculatePointersParam6;
						String copyResultLine = "copy /Y destino " + destino;

						PrintStream psBuild = null;
						String sPathName = sPathTranslateTextFiles
								+ hssfCurrentRow.getCell(33).toString();
						String sBuildName = "rebuild"
								+ ((!"-".equals(hssfCurrentRow.getCell(2)
										.toString())) ? ("_" + (new Double(
										Double.parseDouble(hssfCurrentRow
												.getCell(2).toString())))
										.intValue()) : "") + ".bat";
						try {
							File fBuildOutput = new File(sPathName, sBuildName);
							if (fBuildOutput.exists())
								fBuildOutput.delete();
							psBuild = new PrintStream(new BufferedOutputStream(
									new FileOutputStream(fBuildOutput)));

							psBuild.print(situatedBuildPathLine);
							psBuild.println();
							psBuild.print(copyOriginLine);
							psBuild.println();
							psBuild.print(copyDestinyLine);
							psBuild.println();
							psBuild.print(extractPostInstructionsLine);
							psBuild.println();
							psBuild.print(insertPostInstructionsFrancesLine);
							psBuild.println();
							psBuild.print(insertMargenFrancesLine);
							psBuild.println();
							psBuild.print(deletePostLine);
							psBuild.println();
							psBuild.print(recalculatePointersLine);
							psBuild.println();
							psBuild.print(copyResultLine);
							psBuild.println();

						} catch (IOException ioe) {
							System.err
									.println("ERROR: Problemas al leer el fichero "
											+ sPathName
											+ File.separatorChar
											+ sBuildName
											+ ". Vuelva a intentarlo.");

						} catch (Exception e) {
							System.err.println("ERROR DESCONOCIDO.");
							System.err.println(e.getMessage());

						} finally {
							if (psBuild != null)
								psBuild.close();
						}

						psBuildAll.print("call \"" + sPathName
								+ File.separatorChar + sBuildName + "\"");
						psBuildAll.println();

					}
				}

				System.out
						.println("Ficheros build.bat generados correctamente.");
				System.out.println("Lanza el archivo "
						+ sPathTranslateTextFiles + File.separatorChar
						+ "rebuildAll.bat para ejecutarlos todos.");

			} catch (IOException ioe) {
				System.err.println("ERROR: Problemas al leer el fichero "
						+ sPathTranslateTextFiles + File.separatorChar
						+ "rebuildAll.bat" + ". Vuelva a intentarlo.");

			} catch (Exception e) {
				System.err.println("ERROR DESCONOCIDO.");
				System.err.println(e.getMessage());

			} finally {
				if (psBuildAll != null)
					psBuildAll.close();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static int hex2decimal(String s) {
		String digits = "0123456789ABCDEF";
		s = s.toUpperCase();
		int val = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			int d = digits.indexOf(c);
			val = 16 * val + d;
		}
		return val;
	}

}
