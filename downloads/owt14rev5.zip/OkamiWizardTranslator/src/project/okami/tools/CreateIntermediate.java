package project.okami.tools;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;

import project.okami.tools.Constants;

/**
 * Wizard que facilita la traducci�n del videojuego OKAMI.
 */

/**
 * @author pignium
 * @version 1.4
 * 
 */
public class CreateIntermediate {

	/**
	 * M�todo principal.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Objetos dependientes de la plataforma que almacenan los signos
		// textuales en cada plataforma:
		// Cargamos PS2.properties
		ResourceBundle bundle = ResourceBundle
				.getBundle(Constants.PS2_PLATFORM_NAME);
		Constants.config_ps2 = new Hashtable<String, String>();
		for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			Constants.config_ps2.put(key, bundle.getString(key));
		}

		// Cargamos WII.properties
		bundle = ResourceBundle.getBundle(Constants.WII_PLATFORM_NAME);
		Constants.config_wii = new Hashtable<String, String>();
		for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			Constants.config_wii.put(key, bundle.getString(key));
		}

		BufferedReader teclado = new BufferedReader(new InputStreamReader(
				System.in));

		System.out
				.println("_______________________________ RESULTTEXT2INTERMEDIATE _______________________________\n");

		boolean bHasMoreParts = true;
		String sPathName = "C:\\";
		String sInputFileName = "prueba";
		boolean bMultiParts = false;
		int nInputInitPart = 1;
		int nLineLenght = Constants.N_LINE_LENGTH_DEFAULT;
		try {
			System.out
					.println("Introduzca la ruta donde est� ubicado el texto resultado a partir del cual se quiere generar el intermediate:");
			sPathName = teclado.readLine();
			System.out
					.println("Introduzca el nombre del fichero que contiene el texto resultado a partir del cual se quiere generar el intermediate:");
			sInputFileName = teclado.readLine();
			boolean bOptionCorrect = false;
			while (!bOptionCorrect) {
				int nOption = insertInt(teclado,
						"�El texto original est� dividido en varias partes (Si=1\\No=0)?");
				if (nOption == 0 || nOption == 1) {
					bOptionCorrect = true;
					bMultiParts = (nOption == 1);
					if (bMultiParts) {
						nInputInitPart = insertInt(teclado,
								"Indique por favor la parte por la que desea comenzar: ");
						if (nInputInitPart > 0)
							bOptionCorrect = true;
						else {
							System.err
									.println("ERROR: La parte inicial no puede ser inferior a 1.");

							bOptionCorrect = false;
						}
					}
				}
			}

			String sPlatform = "";

			bOptionCorrect = false;
			while (!bOptionCorrect) {
				System.out
						.println("Indique la plataforma para la que desea crear el fichero intermediate (PS2|WII): ");
				sPlatform = teclado.readLine();
				if (Constants.PS2_PLATFORM_NAME.equals(sPlatform)
						|| Constants.WII_PLATFORM_NAME.equals(sPlatform))
					bOptionCorrect = true;
				else
					System.err
							.println("ERROR: La plataforma tiene que ser PS2 o WII.");
			}

			int nInitialParagraph;

			while (bHasMoreParts) {

				nInitialParagraph = 0;

				String sIntermediateOutputFileNameComplete = sInputFileName
						+ Constants.SUFFIX_FILE_NAME_INTER_TEXT
						+ (bMultiParts ? "_" + nInputInitPart : "")
						+ Constants.EXTENSION_TEXT;

				String sInputFileNameComplete = sInputFileName
						+ (bMultiParts ? "_" + nInputInitPart : "")
						+ Constants.EXTENSION_TEXT;
				List<String[][]> lParagraphs = loadOriginalTextIntoList(
						sPathName, sInputFileNameComplete, bMultiParts,
						nInitialParagraph, ((Constants.PS2_PLATFORM_NAME)
								.equals(sPlatform)) ? Constants.config_ps2
								: Constants.config_wii);

				if (lParagraphs != null) {

					if (lParagraphs.size() > 0) {

						nInitialParagraph = generateIntermediateCode(
								sPathName,
								sIntermediateOutputFileNameComplete,
								lParagraphs,
								teclado,
								nLineLenght,
								((Constants.PS2_PLATFORM_NAME)
										.equals(sPlatform)) ? Constants.config_ps2
										: Constants.config_wii, sPlatform);
					}
					if (nInitialParagraph > 0) {
						bOptionCorrect = false;
						if (nInitialParagraph == lParagraphs.size()) {
							// Hemos traducido todo el fichero completo
							System.out
									.println("Se ha creado correctamente el fichero intermediate.");
						} else {
							System.out
									.println("No se ha creado correctamente el fichero intermediate. "
											+ "Se ha producido un error despues de procesar el p�rrafo "
											+ nInitialParagraph);
						}
					}
				}
				if (bMultiParts)
					nInputInitPart++;
				else
					bHasMoreParts = false;
			}
		} catch (IOException ioe) {
			System.err
					.println("ERROR: Problemas al intentar introducir datos por teclado. Saliendo de TEXT2INTERMEDIATE...");
			System.exit(0);
		}
		System.out.println("TEXT2INTERMEDIATE cerrado correctamente.");

	}

	/**
	 * Almacena los distintos parrafos de los que est� compuesto el texto
	 * original en una estructura List<String[][]>. Un parrafo se considerar�
	 * aquella parte del texto original que acaba con el simbolo
	 * SYMBOL_SEPARATOR_PARAGRAPH. Cada p�rrafo se representa por una estructura
	 * String[][].
	 * 
	 * @param fInputStream
	 *            Fichero que contiene el texto original.
	 * @return Lista que almacena los p�rrafos del texto original.
	 * @throws FileNotFoundException
	 */
	private static List<String[][]> loadOriginalTextIntoList(String sPathName,
			String sInputFileNameComplete, boolean bMultiParts,
			int nInitialParagraph, Hashtable<String, String> config_platform) {

		FileInputStream fInputStream = null;
		List<String[][]> lParagraphs = null;
		int nReadParagraphs = 0;
		try {
			fInputStream = new FileInputStream(new File(sPathName,
					sInputFileNameComplete));

			lParagraphs = new ArrayList<String[][]>();
			char cCurrentChar;
			String sParagraph = "";

			while (fInputStream.available() > 0) {
				cCurrentChar = (char) fInputStream.read();
				sParagraph += cCurrentChar;
				if (sParagraph.endsWith(config_platform
						.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {
					++nReadParagraphs;
					if (nReadParagraphs > nInitialParagraph) {
						lParagraphs.add(processParagraph(sParagraph,
								config_platform));
					}
					sParagraph = "";
				}
			}

		} catch (FileNotFoundException fnfe) {
			System.err.println("ERROR: El fichero " + sPathName
					+ File.separatorChar + sInputFileNameComplete
					+ " no existe.");
			if (bMultiParts)
				System.out
						.println("Puede ser que se hayan acabado de procesar todas las partes o que el texto no este dividio en\n partes realmente. Saliendo del OWT...");
			System.exit(0);
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer el fichero "
					+ sPathName + File.separatorChar + sInputFileNameComplete
					+ ". Vuelva a intentarlo.");
			System.exit(0);
		} finally {
			try {
				if (fInputStream != null)
					fInputStream.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return lParagraphs;

	}

	/**
	 * Almacena un parrafo del texto original en una estructura String[][]. Un
	 * p�rrafo contiene una serie de frases que pueden tener o no saltos de
	 * l�nea separadas por el simbolo
	 * SYMBOL_USER_PULSE_PLEASE+SYMBOL_CARRY_RETURN. Cada frase se representa
	 * por una estructura String[2] donde el primer elemento contiene la primera
	 * parte de la frase y el segundo la segunda parte de la frase.
	 * 
	 * @param sParagraphText
	 * @return Array que almacena un p�rrafo del texto original.
	 */
	private static String[][] processParagraph(String sParagraphText,
			Hashtable<String, String> config_platform) {

		// Detectamos si se necesita pulsaci�n de bot�n o no.
		String symbolPagesSeparator = config_platform
				.get(Constants.SYMBOL_USER_PULSE_PLEASE);
		if (sParagraphText.indexOf(symbolPagesSeparator) < 0
				&& sParagraphText.indexOf(config_platform
						.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) > 0) {
			symbolPagesSeparator = config_platform
					.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE);
		}

		String[] sPreProcessParagraphText = sParagraphText
				.split(symbolPagesSeparator);
		String[][] sProcessPointerText = null;
		// No encuentra ning�n simbolo de divisi�n y almacena la frase de la
		// siguiente manera:
		// 1 [contenido_parrafo_completo][null]
		// 2 [marca_fin_parrafo][null]
		// if (sPreProcessParagraphText.length == 1) {
		// sProcessPointerText = new String[2][LINES_PER_SENTENCE];
		// sProcessPointerText[0][0] = sPreProcessParagraphText[0].substring(
		// 0, sPreProcessParagraphText[0].indexOf(Constants.config_ps2
		// .get(Constants.SYMBOL_SEPARATOR_PARAGRAPH)));
		// sProcessPointerText[1][0] = Constants.config_ps2
		// .get(Constants.SYMBOL_SEPARATOR_PARAGRAPH);
		// } else {
		// Encuentra mas de un simbolo de divisi�n por lo que se almacena:
		// i [Linea_superior_frase][(Linea_inferior_frase)]
		// N [splitSymbol+(caracteres_aleatorios)][marca_fin_parrafo]
		sProcessPointerText = new String[sPreProcessParagraphText.length][Constants.LINES_PER_SENTENCE];
		int i = 0;
		for (; i < sPreProcessParagraphText.length - 1; i++) {
			String sCurrentText = sPreProcessParagraphText[i];
			String[] sSplitTextPerLines = sCurrentText.split(config_platform
					.get(Constants.SYMBOL_CARRY_RETURN));
			boolean bSaltoLinea = sSplitTextPerLines.length == Constants.LINES_PER_SENTENCE ? true
					: false;
			sProcessPointerText[i][0] = sSplitTextPerLines[0];
			sProcessPointerText[i][1] = bSaltoLinea ? sSplitTextPerLines[1]
					: null;
		}
		sProcessPointerText[i][0] = symbolPagesSeparator
				+ sPreProcessParagraphText[i].substring(0,
						sPreProcessParagraphText[i].indexOf(config_platform
								.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH)));
		sProcessPointerText[i][1] = config_platform
				.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH);
		// }
		return sProcessPointerText;

	}

	/**
	 * M�todo que va solicitando al usuario el texto traducido.
	 * 
	 * @param fOutPut
	 * @throws IOException
	 */
	private static int generateIntermediateCode(String sPathName,
			String sIntermediateOutputFileNameComplete,
			List<String[][]> lParagraphs, BufferedReader teclado,
			int nLineLenght, Hashtable<String, String> config_platform,
			String platform) {

		PrintStream psIntermediate = null;
		boolean bSalir = false;
		int nParagraph = 0;
		int nResultPosition = -1;
		int nResultLength = 0;

		// Eliminamos del nombre la cadena _ps2_resultado, _wii_resultado o
		// _resultado
		if (sIntermediateOutputFileNameComplete
				.indexOf(Constants.SUFFIX_PS2_FILE_NAME_SPANISH_TEXT) >= 0) {
			nResultPosition = sIntermediateOutputFileNameComplete
					.indexOf(Constants.SUFFIX_PS2_FILE_NAME_SPANISH_TEXT);
			nResultLength = Constants.SUFFIX_PS2_FILE_NAME_SPANISH_TEXT
					.length();
		} else if (sIntermediateOutputFileNameComplete
				.indexOf(Constants.SUFFIX_WII_FILE_NAME_SPANISH_TEXT) >= 0) {
			nResultPosition = sIntermediateOutputFileNameComplete
					.indexOf(Constants.SUFFIX_WII_FILE_NAME_SPANISH_TEXT);
			nResultLength = Constants.SUFFIX_WII_FILE_NAME_SPANISH_TEXT
					.length();
		} else if (sIntermediateOutputFileNameComplete.indexOf("_resultado") >= 0) {
			nResultPosition = sIntermediateOutputFileNameComplete
					.indexOf("_resultado");
			nResultLength = "_resultado".length();
		}
		if (nResultPosition >= 0)
			sIntermediateOutputFileNameComplete = sIntermediateOutputFileNameComplete
					.substring(0, nResultPosition)
					+ ((Constants.WII_PLATFORM_NAME).equals(platform) ? "_wii"
							: "")
					+ sIntermediateOutputFileNameComplete.substring(
							nResultPosition + nResultLength,
							sIntermediateOutputFileNameComplete.length());

		try {

			// Intentamos generar el fichero intermediate
			File fIntermediateOutput = new File(sPathName,
					sIntermediateOutputFileNameComplete);
			if (fIntermediateOutput.exists()) {
				System.err
						.println("El fichero intermediate ya existe. Borralo manualmente si realmente desea regenerarlo.");
				return -1;
			} else {
				psIntermediate = new PrintStream(new BufferedOutputStream(
						new FileOutputStream(fIntermediateOutput)));
			}

			String sIntermediateText = "";
			String symbolPulse = "";
			String asIntermediateTextAux[] = new String[3];
			asIntermediateTextAux[0] = "";
			asIntermediateTextAux[1] = "";
			asIntermediateTextAux[2] = "";
			String[][] currentPages;
			Vector<String> lLineIntermediateFormat;
			for (; nParagraph < lParagraphs.size() && !bSalir; nParagraph++) {
				System.out
						.println("\n\n_______________________________ INICIO DEL P�RRAFO "
								+ (nParagraph + 1)
								+ " DE "
								+ (lParagraphs.size())
								+ " _______________________________");

				currentPages = lParagraphs.get(nParagraph);
				symbolPulse = "";
				sIntermediateText = "";
				if (currentPages[currentPages.length - 1][0]
						.startsWith(config_platform
								.get(Constants.SYMBOL_USER_PULSE_PLEASE)))
					symbolPulse = Constants.SYMBOL_USER_PULSE_PLEASE;
				else if (currentPages[currentPages.length - 1][0]
						.startsWith(config_platform
								.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)))
					symbolPulse = Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE;

				for (int nCurrentPage = 0; nCurrentPage < currentPages.length
						&& !bSalir; nCurrentPage++) {
					if (currentPages[nCurrentPage][0]
							.startsWith(config_platform.get(symbolPulse))
							&& currentPages[nCurrentPage][1] != null
							&& currentPages[nCurrentPage][1]
									.equals(config_platform
											.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {

						// Caso: Si que se ha encontrado un splitSymbol
						// [USER_PULSE_PLEASE|NO_NEED_USER_PULSE_PLEASE]
						// Necesitamos introducir los posibles simbolos
						// extra�os que aparezcan entre el splitSymbol y el
						// final de p�rrafo
						if (currentPages[nCurrentPage][0]
								.indexOf(config_platform.get(symbolPulse)) >= 0) {
							String sAditionalInformation = currentPages[nCurrentPage][0]
									.substring(currentPages[nCurrentPage][0]
											.indexOf(config_platform
													.get(symbolPulse))
											+ config_platform.get(symbolPulse)
													.length());
							if (!sAditionalInformation.equals("")) {
								sIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE
										+ sAditionalInformation
										+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE
										+ Constants.MARK_NO_SPACING_IN_PREVIOUS_TEXT
										+ "\n";
							}
						}
						sIntermediateText += Constants.MARK_FINISH_PARAGRAPH
								+ (nParagraph + 1) + "]";

						psIntermediate.print(sIntermediateText);
						psIntermediate.println();
						psIntermediate.println();

						System.out
								.println("_______________________________ FIN DEL P�RRAFO "
										+ (nParagraph + 1)
										+ " DE "
										+ (lParagraphs.size())
										+ " _______________________________"
										+ "\n\n");
					} else {

						System.out.println(currentPages[nCurrentPage][0]);
						if (currentPages[nCurrentPage][1] != null)
							System.out.println(currentPages[nCurrentPage][1]);

						String sLine;
						for (int nLine = 0; nLine < ((currentPages[nCurrentPage][1] == null) ? 1
								: 2); nLine++) {

							sLine = currentPages[nCurrentPage][nLine];

							// INICIO SUSTITUCIONES DIRECTAS -----------------

							int position = -1;

							// CON SALTO DE LINEA
							if (nLine == 0
									&& currentPages[nCurrentPage][1] != null)
								sLine = sLine + Constants.MARK_CARRY_RETURN;
							if ((nLine == 0 && currentPages[nCurrentPage][1] == null)
									|| nLine == 1) {
								//								
								if (symbolPulse
										.equals(Constants.SYMBOL_USER_PULSE_PLEASE)) {
									sLine = sLine
											+ Constants.MARK_USER_PULSE_PLEASE;
								} else if (symbolPulse
										.equals(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) {
									sLine = sLine
											+ Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
								} else {
									asIntermediateTextAux[2] += "";
								}
							}

							// MARCADO DE TEXTO
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_PREFFIX_RED_TEXT)) >= 0) {
								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_PREFFIX_RED_TEXT));

								sLine = sLine.substring(0, position)
										+ Constants.MARK_INIT_RED_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_PREFFIX_RED_TEXT)
																		.length(),
														sLine.length());
							}
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_SUFFIX_RED_TEXT)) >= 0) {

								position = sLine.indexOf(config_platform
										.get(Constants.SYMBOL_SUFFIX_RED_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_FINISH_RED_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_SUFFIX_RED_TEXT)
																		.length(),
														sLine.length());
							}

							// TEXTO PEQUE�O
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT)) >= 0) {

								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_INIT_SMALL_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_PREFFIX_SMALL_TEXT)
																		.length(),
														sLine.length());
							}
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT)) >= 0) {

								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_FINISH_SMALL_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_SUFFIX_SMALL_TEXT)
																		.length(),
														sLine.length());
							}

							// TEXTO GRANDE
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_PREFFIX_BIG_TEXT)) >= 0) {

								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_PREFFIX_BIG_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_INIT_BIG_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_PREFFIX_BIG_TEXT)
																		.length(),
														sLine.length());
							}
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_SUFFIX_BIG_TEXT)) >= 0) {

								position = sLine.indexOf(config_platform
										.get(Constants.SYMBOL_SUFFIX_BIG_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_FINISH_BIG_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_SUFFIX_BIG_TEXT)
																		.length(),
														sLine.length());
							}

							// TEXTO OPCIONES
							if (sLine
									.indexOf(config_platform
											.get(Constants.SYMBOL_OPTION_TEXT_QUESTION)) >= 0) {

								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_OPTION_TEXT_QUESTION));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_OPTION_TEXT_QUESTION
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_OPTION_TEXT_QUESTION)
																		.length(),
														sLine.length());
							}
							if (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_OPTION_TEXT_DEFAULT)) >= 0) {
								position = sLine
										.indexOf(config_platform
												.get(Constants.SYMBOL_OPTION_TEXT_DEFAULT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_OPTION_TEXT_DEFAULT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_OPTION_TEXT_DEFAULT)
																		.length(),
														sLine.length());
							}
							while (sLine.indexOf(config_platform
									.get(Constants.SYMBOL_OPTION_TEXT)) >= 0) {
								position = sLine.indexOf(config_platform
										.get(Constants.SYMBOL_OPTION_TEXT));
								sLine = sLine.substring(0, position)
										+ Constants.MARK_OPTION_TEXT
										+ sLine
												.substring(
														position
																+ config_platform
																		.get(
																				Constants.SYMBOL_OPTION_TEXT)
																		.length(),
														sLine.length());
							}

							// FINAL SUSTITUCIONES DIRECTAS ------------------

							// Procesamos linea a linea una vez se han
							// sustituido
							// los simbolos por marcas. Dentro de cada linea
							// dividimos en secciones para localizar lo mejor
							// posible los textos

							lLineIntermediateFormat = new Vector<String>();

							char charPosition = ' ';
							String sSaveText = "";
							String sSymbolText = "";
							int nSavePosition = -1;
							for (int i = 0; i < sLine.length(); i++) {

								charPosition = sLine.charAt(i);
								if (charPosition == '[') {

									nSavePosition = i;

									if (i == sLine
											.indexOf(Constants.MARK_CARRY_RETURN)) {
										sSymbolText = Constants.MARK_CARRY_RETURN;
										i += Constants.MARK_CARRY_RETURN
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_USER_PULSE_PLEASE)) {
										sSymbolText = Constants.MARK_USER_PULSE_PLEASE;
										i += Constants.MARK_USER_PULSE_PLEASE
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_NO_NEED_USER_PULSE_PLEASE)) {
										sSymbolText = Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
										i += Constants.MARK_NO_NEED_USER_PULSE_PLEASE
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_INIT_RED_TEXT)) {
										sSymbolText = Constants.MARK_INIT_RED_TEXT;
										i += Constants.MARK_INIT_RED_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_FINISH_RED_TEXT)) {
										sSymbolText = Constants.MARK_FINISH_RED_TEXT;
										i += Constants.MARK_FINISH_RED_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_INIT_SMALL_TEXT)) {
										sSymbolText = Constants.MARK_INIT_SMALL_TEXT;
										i += Constants.MARK_INIT_SMALL_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_FINISH_SMALL_TEXT)) {
										sSymbolText = Constants.MARK_FINISH_SMALL_TEXT;
										i += Constants.MARK_FINISH_SMALL_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_INIT_BIG_TEXT)) {
										sSymbolText = Constants.MARK_INIT_BIG_TEXT;
										i += Constants.MARK_INIT_BIG_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_FINISH_BIG_TEXT)) {
										sSymbolText = Constants.MARK_FINISH_BIG_TEXT;
										i += Constants.MARK_FINISH_BIG_TEXT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_OPTION_TEXT_QUESTION)) {
										sSymbolText = Constants.MARK_OPTION_TEXT_QUESTION;
										i += Constants.MARK_OPTION_TEXT_QUESTION
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_OPTION_TEXT_DEFAULT)) {
										sSymbolText = Constants.MARK_OPTION_TEXT_DEFAULT;
										i += Constants.MARK_OPTION_TEXT_DEFAULT
												.length() - 1;
									}
									if (i == sLine
											.indexOf(Constants.MARK_OPTION_TEXT)) {
										sSymbolText = Constants.MARK_OPTION_TEXT;
										i += Constants.MARK_OPTION_TEXT
												.length() - 1;
									}

									if (nSavePosition != i) {
										if (!("".equals(sSaveText))) {
											lLineIntermediateFormat
													.add(sSaveText);
											sSaveText = "";
										}
										lLineIntermediateFormat
												.add(sSymbolText);
										sSymbolText = "";
									} else {
										sSaveText += sLine.charAt(i);
									}
									nSavePosition = -1;

								} else
									sSaveText += sLine.charAt(i);

							}

							// Procesamos las secciones de la linea he
							// intentamos
							// formatear los textos

							String sCurrentText = "";
							sLine = "";
							for (int i = 0; i < lLineIntermediateFormat.size(); i++) {

								sCurrentText = lLineIntermediateFormat.get(i);
								if (!(sCurrentText.charAt(0) == '[' && sCurrentText
										.charAt(sCurrentText.length() - 1) == ']')) {
									sCurrentText = formatText(sCurrentText,
											(i == 0), platform);
								}

								sLine += sCurrentText;
							}

							psIntermediate.print(sLine);
							if (sCurrentText
									.indexOf(Constants.MARK_USER_PULSE_PLEASE) >= 0
									|| sCurrentText
											.indexOf(Constants.MARK_NO_NEED_USER_PULSE_PLEASE) >= 0)
								psIntermediate.println();
							psIntermediate.println();

						}

					}
				}
				psIntermediate.println();
			}
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer el fichero "
					+ sPathName + File.separatorChar
					+ sIntermediateOutputFileNameComplete
					+ ". Vuelva a intentarlo.");

		} catch (Exception e) {
			System.err.println("ERROR DESCONOCIDO.");
			System.err.println(e.getMessage());

		} finally {
			if (psIntermediate != null)
				psIntermediate.close();
		}
		return nParagraph;
	}

	/**
	 * M�todo auxiliar para controlar que el usuario introduce realmente un
	 * entero por pantalla.
	 * 
	 * @param teclado
	 * @param texto
	 * @return
	 */
	private static int insertInt(BufferedReader teclado, String texto) {
		int nResultado = 0;
		boolean bInvalidPosition = true;
		while (bInvalidPosition) {
			System.out.println(texto);
			try {
				nResultado = Integer.parseInt(teclado.readLine());
				bInvalidPosition = false;
			} catch (NumberFormatException e) {
				System.err.println("\nERROR: Debe introducir un n�mero.");

			} catch (IOException e) {
				System.err
						.println("\nERROR: No se detect� correctamente el texto.");

			}
		}
		return nResultado;
	}

	/**
	 * M�todo que intenta formatear la variable text lo mejor que puede.
	 * 
	 * @param text
	 * @param isFirstPart
	 * @return text con formato intermediate
	 */
	private static String formatText(String text, boolean isFirstPart,
			String platform) {

		String sResult = "";
		try {
			int nPositionInf = -1;
			int nPositionSup = -1;
			String previousPair = "XX";
			String currentPair = "XX";
			boolean bIsText = false;

			nPositionSup = text.length();
			int i = text.length() - 2;
			int nBlankPosition = Constants.PS2_PLATFORM_NAME.equals(platform) ? 1
					: 0;
			int nCharacterPosition = Constants.PS2_PLATFORM_NAME
					.equals(platform) ? 0 : 1;

			// Evaluamos de atras->adelante
			for (; i >= 0; i = (i - 2)) {
				currentPair = text.substring(i, i + 2);
				if (currentPair.charAt(nBlankPosition) == ' '
						&& (((byte) currentPair.charAt(nCharacterPosition) >= 65 && (byte) currentPair
								.charAt(nCharacterPosition) <= 90)
								|| // A-Z
								((byte) currentPair.charAt(nCharacterPosition) >= 97 && (byte) currentPair
										.charAt(nCharacterPosition) <= 122)
								|| // a-z
								((byte) currentPair.charAt(nCharacterPosition) >= 48 && (byte) currentPair
										.charAt(nCharacterPosition) <= 57)
								|| // 0-9
								((byte) currentPair.charAt(nCharacterPosition) == 44)
								|| // ,
								((byte) currentPair.charAt(nCharacterPosition) == 46)
								|| // .
								((byte) currentPair.charAt(nCharacterPosition) == 58)
								|| // :
								((byte) currentPair.charAt(nCharacterPosition) == 59)
								|| // ;
								((byte) currentPair.charAt(nCharacterPosition) == -31)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -23)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -19)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -13)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -6)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -63)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -55)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -51)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -45)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -38)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -15)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -47)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == 33)
								|| // !
								((byte) currentPair.charAt(nCharacterPosition) == -95)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == -65)
								|| // �
								((byte) currentPair.charAt(nCharacterPosition) == 63)
								|| // ?
								((byte) currentPair.charAt(nCharacterPosition) == 64)
								|| // @
								((byte) currentPair.charAt(nCharacterPosition) == 39) || // '
						((byte) currentPair.charAt(nCharacterPosition) == 32)) // Posici�n
				// en
				// blanco
				)
					bIsText = true;
				else
					bIsText = false;

				// Buscamos cosas sospechosas sino seguimos adelante
				if ("  ".equals(previousPair) && "  ".equals(currentPair))
					bIsText = false;

				if (bIsText)
					nPositionInf = i;

				if (!bIsText || i == 0) {
					// A partir de aqui hay que andar con cuidado pues ya no se
					// trata de texto
					sResult = Constants.MARK_INIT_TEXT_TO_TRANSLETE
							+ applyUnspacingText(text.substring(nPositionInf,
									nPositionSup), platform)
							+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE + sResult;
					nPositionSup = nPositionInf;
					if (nPositionSup != 0) {
						if (isFirstPart)

							sResult = Constants.MARK_INIT_HEADER
									+ text.substring(0, nPositionSup)
									+ Constants.MARK_FINISH_HEADER + sResult;
						else
							sResult = Constants.MARK_INIT_TEXT_TO_TRANSLETE
									+ text.substring(0, nPositionSup)
									+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE
									+ Constants.MARK_NO_SPACING_IN_PREVIOUS_TEXT
									+ sResult;
					}
					i = 0;
				}

				previousPair = currentPair;

			}
		} catch (StringIndexOutOfBoundsException sioobe) {
			// Capturamos y envolvemos el texto
			sResult = Constants.MARK_INIT_HEADER + text
					+ Constants.MARK_FINISH_HEADER;
		}
		return sResult;
	}

	/**
	 * M�todo que elimina espacios en el texto que se le pasa como par�metro.
	 * Valido para la plataforma PS2.
	 * 
	 * @param sText
	 * @return
	 */
	private static String applyUnspacingText(String text, String platform) {
		String sUnspacedUserText = "";
		if (!text.equals("")) {
			for (int nUserTextPos = 0; nUserTextPos < text.length(); nUserTextPos++) {
				if (nUserTextPos % 2 == 0
						&& Constants.PS2_PLATFORM_NAME.equals(platform))
					sUnspacedUserText += text.charAt(nUserTextPos);
				else if (nUserTextPos % 2 == 1
						&& Constants.WII_PLATFORM_NAME.equals(platform))
					sUnspacedUserText += text.charAt(nUserTextPos);
			}
		}
		return sUnspacedUserText;
	}

}