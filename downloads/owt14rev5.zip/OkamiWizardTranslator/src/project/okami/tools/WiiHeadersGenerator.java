package project.okami.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.io.InputStreamReader;

public class WiiHeadersGenerator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		BufferedReader teclado = new BufferedReader(new InputStreamReader(
//				System.in));

		System.out
				.println("_______________________________ BIENVENIDO A OKAMI WIZARD TRANSLATOR _______________________________\n");
		
		System.out
				.println("Introduzca el fichero PS2 intermediate origen:");
//			String sIntermediatePS2PathName = teclado.readLine();
		String sIntermediatePS2PathName = "E:/workpath/SVN/PS2/text/r102/r102_intermediate.txt"; 
		
		System.out
			.println("Introduzca el fichero PS2 fuente origen:");
//			String sSourcePS2PathName = teclado.readLine();
		String sSourcePS2PathName = "E:/workpath/SVN/PS2/text/r102/r102.txt";
		
		System.out
			.println("Introduzca el fichero WII fuente origen:");
//			String sSourceWIIPathName = teclado.readLine();
		String sSourceWIIPathName = "E:/workpath/SVN/WII/text/r102/r102_wii.txt";
		
		BufferedReader brIntermediate = null;
		BufferedReader brPS2Source = null;
		BufferedReader brWIISource = null;
		String sLine = "";
		String sHeaderPS2 = "";
		String sHeaderWII = "";
		String sPS2Source = "";
		String sWIISource = "";
		int nDataLength = 0;
		boolean bFound = true;
		try {
			brIntermediate = new BufferedReader(new FileReader(new File(
					sIntermediatePS2PathName)));
			brPS2Source = new BufferedReader(new FileReader(new File(
					sSourcePS2PathName)));
			sPS2Source = brPS2Source.readLine();
			brWIISource = new BufferedReader(new FileReader(new File(
					sSourceWIIPathName)));
			sWIISource = brWIISource.readLine();
			while (brIntermediate.ready()) {
				if ( bFound ) {
					sLine = brIntermediate.readLine();
				}
				if (sLine.startsWith(Constants.MARK_INIT_HEADER)) {
					sHeaderPS2 = sLine.substring(
							sLine.indexOf(Constants.MARK_INIT_HEADER) + Constants.MARK_INIT_HEADER.length(),
							sLine.indexOf(Constants.MARK_FINISH_HEADER));
					if( sHeaderPS2.equals("!ӣ�Za. ?���Za") )
						System.out.println();
					if(sHeaderPS2.length() > 0) {
						nDataLength = sPS2Source.indexOf(sHeaderPS2);
						if(nDataLength < 0 ) {
							System.out.println();
						} else {
							if( sWIISource.substring(nDataLength).
									startsWith(sWIISource.substring(nDataLength, nDataLength + sHeaderPS2.length()) + " ") ||
								sWIISource.substring(nDataLength).
									startsWith(sWIISource.substring(nDataLength, nDataLength + sHeaderPS2.length()) + "�, v ")) {
								sHeaderWII = sWIISource.substring(nDataLength, nDataLength + sHeaderPS2.length());
								System.out.println(sHeaderWII);
								bFound = true;
							} else {
								bFound = false;
							}
						}
					} else {
						sHeaderWII = sHeaderPS2;
					}
					
					sPS2Source = sPS2Source.substring(sPS2Source.indexOf(sHeaderPS2.substring(0, sHeaderPS2.length())) + sHeaderPS2.length());
					sWIISource = sWIISource.substring(sWIISource.indexOf(sHeaderWII.substring(0, sHeaderPS2.length())) + sHeaderPS2.length());
					
				}
			}
		} catch (FileNotFoundException fnfe) {
			System.out.println("ERROR: Los ficheros no existen.");
			System.exit(0);
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer los ficheros. Vuelva a intentarlo.");
			System.exit(0);
		} catch (IndexOutOfBoundsException e) {
			System.err.println("ERROR: Problemas al calcular posici�n de cabeceras.");
			System.exit(0);
		} finally {
			try {
				if (brIntermediate != null)
					brIntermediate.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		System.out.println("Cabeceras para el fichero wii extraidas.");
		
	}

}
