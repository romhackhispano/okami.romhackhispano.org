package project.okami.tools;

import java.io.File;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.ResourceBundle;

import project.okami.translator.OkamiWizardTranslator;



public class ReinsertDetector {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ResourceBundle bundle = ResourceBundle.getBundle(Constants.PS2_PLATFORM_NAME);
		Constants.config_ps2 = new Hashtable<String, String>();
		for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			Constants.config_ps2.put(key, bundle.getString(key));
		}
		
		System.out
				.println("_______________________________ DETECTOR DE FICHEROS A REINSERTAR _______________________________\n");

		String sPathName = "E:/workpath/SVN/PS2/text/";
		
		String sTranslatesPathName = "E:/workpath/SVN/PS2/extractTranslate";

		File fCurrentFile = new File(sPathName);

		File[] fFileSet = fCurrentFile.listFiles();

		for (int i = 0; i < fFileSet.length; i++) {

			long lLastModification = 0;

			File fCurrentResultDirectory = fFileSet[i];
			if( fCurrentResultDirectory.isDirectory() && !fCurrentResultDirectory.getName().equals(".svn") ) {
									
				File[] fFileSetResults = fCurrentResultDirectory.listFiles(new FileFilterResults());
				if(fFileSetResults != null && fFileSetResults.length > 0 ) {
					
					switch (fFileSetResults.length) {
					
					case 1:
						// File *_resultado.txt only
						lLastModification = fFileSetResults[0].lastModified();
						break;
					case 2:
						// File *_intermediate.txt and *_resultado.txt || Set of TWO *_resultado.txt
						if(fFileSetResults[0].getName().indexOf("_intermediate") > 0 || fFileSetResults[1].getName().indexOf("_intermediate") > 0) {
							File fFileIntermediate = null;
							File fFileResult = null;
							if ( fFileSetResults[0].getName().indexOf("_intermediate") > 0 ) {
								fFileIntermediate = fFileSetResults[0];
								fFileResult = fFileSetResults[1];
							} else {
								fFileIntermediate = fFileSetResults[1];
								fFileResult = fFileSetResults[0];
							}
							if (fFileIntermediate.lastModified() > fFileResult.lastModified()) {
								System.out.print("Regenerando fichero de traducci�n -> " + fCurrentResultDirectory.getAbsolutePath() + "...");
								String sIntermediateOutputFileNameComplete = fCurrentResultDirectory.getName() + "_intermediate.txt";
								String sOutputFileNameComplete = fCurrentResultDirectory.getName() + "_ps2_resultado.txt";
								String sPlatform = "PS2";
								OkamiWizardTranslator.generateResult(fCurrentResultDirectory.getAbsolutePath(), sIntermediateOutputFileNameComplete, sOutputFileNameComplete, sPlatform);
								System.out.println(" HECHO");
								lLastModification = (new Date()).getTime();
							}
							break;
						}
					default:
						// Set of *_resultado.txt
						for (int j = 0; j < fFileSetResults.length; j++) {
							
							File fCurrentResultFile = fFileSetResults[j];
							if (fCurrentResultFile.lastModified() > lLastModification )
								lLastModification = fCurrentResultFile.lastModified();
													
						}
					}
					
				}
				
			}
			
			String[] sTranslateDirectories = new String [] { sTranslatesPathName + "/common/",
													sTranslatesPathName + "/r1XX/",
													sTranslatesPathName + "/r2XX/",
													sTranslatesPathName + "/r3XX/",
													sTranslatesPathName + "/rcXX/",
													sTranslatesPathName + "/rfXX/",
													sTranslatesPathName + "/reXX/",} ;
			boolean bFound = false;
			
			for(int iCurrentDirectory = 0; iCurrentDirectory < sTranslateDirectories.length && !bFound; iCurrentDirectory++) {
				
				File fCurrentTranslateDirectory = new File(sTranslateDirectories[iCurrentDirectory]);
				File[] fTranslateFiles = fCurrentTranslateDirectory.listFiles();
				
				for(int iCurrentFile = 0; iCurrentFile < fTranslateFiles.length && !bFound; iCurrentFile++) {
					if(	fTranslateFiles[iCurrentFile].getName().startsWith(fCurrentResultDirectory.getName())) {
						if(lLastModification > fTranslateFiles[iCurrentFile].lastModified())
							System.out.println("WARNING: Debe reinsertar " + fCurrentResultDirectory.getAbsolutePath() + " en " + fTranslateFiles[iCurrentFile].getAbsolutePath());
						bFound = true;
					}
				}
				
			}
			
			if (!bFound)
				System.out.println("WARNING: Debe extraer el fichero donde reinsertar " + fCurrentResultDirectory.getAbsolutePath() );
			
		}

	}

}
