package project.okami.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class CreateFiles {

//	public static final String FILEPATH = "D:\\Okami\\PS2\\text\\iteminfo";
	public static final String FILEPATH = "C:/iteminfo";

	public static final String FILENAME = "iteminfo_wii_resultado";

	public static final String SUFFIX = "_";

	public static final String EXTENSION_TEXT = ".txt";

	/**
	 * M�todo principal.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int i = 1;
		BufferedReader brHelper = null;
		try {
			brHelper = new BufferedReader(new FileReader(new File(FILEPATH,
					FILENAME + EXTENSION_TEXT)));
			while (brHelper.ready()) {
				String sLine = brHelper.readLine();
				System.out.println("Leyendo nueva l�nea.");
				FileOutputStream fExportStream = new FileOutputStream(new File(
						FILEPATH, FILENAME + SUFFIX + i + EXTENSION_TEXT));
				for (int nChar = 0; nChar < sLine.length(); nChar++) {
					fExportStream.write(sLine.charAt(nChar));
				}
				System.out.println("-> Creado el fichero: " + FILEPATH
						+ File.separatorChar + FILENAME + SUFFIX + i++
						+ EXTENSION_TEXT + "\n");
			}
		} catch (IOException ioe) {
			System.err
					.println("WARNING: Problemas al leer el fichero. Vuelva a intentarlo");
			System.err.println(ioe.getMessage());
		} finally {
			try {
				if (brHelper != null)
					brHelper.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
	}

}
