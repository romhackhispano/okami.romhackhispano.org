package project.okami.tools;

import java.io.File;
import java.io.FilenameFilter;

public class FileFilterResults implements FilenameFilter {
	
	@Override
	public boolean accept(File dir, String name) {

		if( (name.indexOf("_intermediate") > 0 ||
			 name.indexOf("_ps2_resultado_") > 0 ||
			 name.endsWith("_ps2_resultado.txt") ||
			 name.startsWith(dir.getName() + "_resultado") ||
			 name.startsWith(dir.getName() + "_resultado_")) && 
			!name.endsWith(".export") )
			
			return true;
		
		else
			return false;
		
	}
	
}