package project.okami.translator;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import project.okami.tools.Constants;

/**
 * Wizard que facilita la traducci�n del videojuego OKAMI.
 */

/**
 * @author pignium
 * @version 1.4
 * 
 */
public class OkamiWizardTranslator {

	/**
	 * M�todo principal.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		ResourceBundle bundle = ResourceBundle
				.getBundle(Constants.PS2_PLATFORM_NAME);
		Constants.config_ps2 = new Hashtable<String, String>();
		for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			Constants.config_ps2.put(key, bundle.getString(key));
		}

		bundle = ResourceBundle.getBundle(Constants.WII_PLATFORM_NAME);
		Constants.config_wii = new Hashtable<String, String>();
		for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
			String key = (String) e.nextElement();
			Constants.config_wii.put(key, bundle.getString(key));
		}

		BufferedReader keyboard = new BufferedReader(new InputStreamReader(
				System.in));

		System.out
				.println("_______________________________ BIENVENIDO A OKAMI WIZARD TRANSLATOR _______________________________\n");

		boolean bHasMoreParts = true;
		String sPathName = "";
		String sInputFileName = "";
		boolean bMultiParts = false;
		int nInputInitPart = 1;
		int nLineLenght = Constants.N_LINE_LENGTH_DEFAULT;
		try {
			System.out
					.println("Introduzca la ruta donde est� ubicado el texto original:");
			sPathName = keyboard.readLine();
			System.out
					.println("Introduzca el nombre del fichero que contiene el texto original:");
			sInputFileName = keyboard.readLine();
			boolean bOptionCorrect = false;
			while (!bOptionCorrect) {
				int nOption = insertInt(keyboard,
						"�El texto original est� dividido en varias partes (Si=1\\No=0)?");
				if (nOption == 0 || nOption == 1) {
					bOptionCorrect = true;
					bMultiParts = (nOption == 1);
					if (bMultiParts) {
						nInputInitPart = insertInt(keyboard,
								"Indique por favor la parte por la que desea comenzar: ");
						if (nInputInitPart > 0)
							bOptionCorrect = true;
						else {
							System.err
									.println("ERROR: La parte inicial no puede ser inferior a 1.");

							bOptionCorrect = false;
						}
					}
				}
			}

			while (bHasMoreParts) {

				String sIntermediateOutputFileNameComplete = sInputFileName
						+ Constants.SUFFIX_FILE_NAME_INTER_TEXT
						+ (bMultiParts ? "_" + nInputInitPart : "")
						+ Constants.EXTENSION_TEXT;

				int nInitialParagraph = calculateInitialParagraph(sPathName,
						sIntermediateOutputFileNameComplete);

				String sInputFileNameComplete = sInputFileName
						+ (bMultiParts ? "_" + nInputInitPart : "")
						+ Constants.EXTENSION_TEXT;
				List<String[][]> lParagraphs = loadOriginalTextIntoList(
						sPathName, sInputFileNameComplete, bMultiParts,
						nInitialParagraph);

				System.out
						.println("\nSe ha recuperado el �ltimo CHECKPOINT del fichero con la traducci�n "
								+ sPathName
								+ File.separatorChar
								+ sIntermediateOutputFileNameComplete
								+ "\n-> Existen "
								+ nInitialParagraph
								+ " p�rrafo/s traducidos de "
								+ (nInitialParagraph + lParagraphs.size())
								+ ".\n");

				if (lParagraphs != null) {

					if (lParagraphs.size() > 0) {

						String sHelperTextFileName = sInputFileName
								+ Constants.EXTENSION_HELPER_TEXT;
						Map<String, String> mTranslateMap = loadHelperTextToMap(
								sPathName, sHelperTextFileName);

						nInitialParagraph = translate(sPathName,
								sIntermediateOutputFileNameComplete,
								lParagraphs, mTranslateMap, keyboard,
								nInitialParagraph, nLineLenght);
					}
					if (nInitialParagraph > 0) {
						bOptionCorrect = false;
						int nOption = 0;
						while (!bOptionCorrect) {
							if (nInitialParagraph == (nInitialParagraph + lParagraphs
									.size())) {
								// Hemos traducido todo el fichero completo
								nOption = insertInt(
										keyboard,
										"Se han traducido todos los p�rrafos completamente. �Desea crear fichero resultado (S�=1\\No=0)?");
							} else {
								nOption = insertInt(
										keyboard,
										"No se han traducido todos los p�rrafos completamente. �Desea crear fichero resultado (S�=1\\No=0)?");
							}
							if (nOption == 0 || nOption == 1) {
								bOptionCorrect = true;
								if (nOption == 1) {
									System.out
											.println("Introduzca el formato del fichero origen a partir del que se ha realizado la traducci�n ("
													+ Constants.PS2_PLATFORM_NAME
													+ "\\"
													+ Constants.WII_PLATFORM_NAME
													+ "):");
									String sPlatform = keyboard.readLine();
									String sOutputFileNameComplete = "";
									if (sPlatform
											.equals(Constants.PS2_PLATFORM_NAME)) {
										sOutputFileNameComplete = sInputFileName
												+ Constants.SUFFIX_PS2_FILE_NAME_SPANISH_TEXT
												+ (bMultiParts ? "_"
														+ nInputInitPart : "")
												+ Constants.EXTENSION_TEXT;
									} else if (sPlatform
											.equals(Constants.WII_PLATFORM_NAME)) {
										sOutputFileNameComplete = sInputFileName
												+ Constants.SUFFIX_WII_FILE_NAME_SPANISH_TEXT
												+ (bMultiParts ? "_"
														+ nInputInitPart : "")
												+ Constants.EXTENSION_TEXT;
									} else {
										bOptionCorrect = false;
										System.err
												.println("ERROR: Los formatos posibles son "
														+ Constants.PS2_PLATFORM_NAME
														+ " o "
														+ Constants.WII_PLATFORM_NAME
														+ ".");
									}
									boolean bCorrectGeneration = false;
									if (bOptionCorrect) {
										bCorrectGeneration = generateResult(
												sPathName,
												sIntermediateOutputFileNameComplete,
												sOutputFileNameComplete,
												sPlatform);
										if (bCorrectGeneration) {
											String sExportFileNameComplete = sInputFileName
													+ (bMultiParts ? "_"
															+ nInputInitPart
															: "")
													+ "_"
													+ sPlatform
													+ Constants.EXTENSION_EXPORT;

											export(
													sPathName,
													sInputFileNameComplete,
													sOutputFileNameComplete,
													sExportFileNameComplete,
													(nInitialParagraph + lParagraphs
															.size()));
										}
									}
								}
							}
						}
					}
				}
				if (bMultiParts)
					nInputInitPart++;
				else
					bHasMoreParts = false;
			}
		} catch (IOException ioe) {
			System.err
					.println("ERROR: Problemas al intentar introducir datos por teclado. Saliendo del OWT...");
			System.exit(0);
		}
		System.out.println("OWT cerrado correctamente.");

	}

	/**
	 * Almacena los distintos parrafos de los que est� compuesto el texto
	 * original en una estructura List<String[][]>. Un parrafo se considerar�
	 * aquella parte del texto original que acaba con el simbolo
	 * SYMBOL_SEPARATOR_PARAGRAPH. Cada p�rrafo se representa por una estructura
	 * String[][].
	 * 
	 * @param fInputStream
	 *            Fichero que contiene el texto original.
	 * @return Lista que almacena los p�rrafos del texto original.
	 * @throws FileNotFoundException
	 */
	private static List<String[][]> loadOriginalTextIntoList(String sPathName,
			String sInputFileNameComplete, boolean bMultiParts,
			int nInitialParagraph) {

		FileInputStream fInputStream = null;
		List<String[][]> lParagraphs = null;
		int nReadParagraphs = 0;
		try {
			fInputStream = new FileInputStream(new File(sPathName,
					sInputFileNameComplete));

			lParagraphs = new ArrayList<String[][]>();
			char cCurrentChar;
			String sParagraph = "";

			while (fInputStream.available() > 0) {
				cCurrentChar = (char) fInputStream.read();
				sParagraph += cCurrentChar;
				if (sParagraph.endsWith(Constants.config_ps2
						.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {
					++nReadParagraphs;
					if (nReadParagraphs > nInitialParagraph) {
						lParagraphs.add(processParagraph(sParagraph));
					}
					sParagraph = "";
				}
			}

		} catch (FileNotFoundException fnfe) {
			System.err.println("ERROR: El fichero " + sPathName
					+ File.separatorChar + sInputFileNameComplete
					+ " no existe.");
			if (bMultiParts)
				System.out
						.println("Puede ser que se hayan acabado de procesar todas las partes o que el texto no este dividio en\n partes realmente. Saliendo del OWT...");
			System.exit(0);
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer el fichero "
					+ sPathName + File.separatorChar + sInputFileNameComplete
					+ ". Vuelva a intentarlo.");
			System.exit(0);
		} finally {
			try {
				if (fInputStream != null)
					fInputStream.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return lParagraphs;

	}

	/**
	 * Almacena un parrafo del texto original en una estructura String[][]. Un
	 * p�rrafo contiene una serie de frases que pueden tener o no saltos de
	 * l�nea separadas por el simbolo
	 * SYMBOL_USER_PULSE_PLEASE+SYMBOL_CARRY_RETURN. Cada frase se representa
	 * por una estructura String[2] donde el primer elemento contiene la primera
	 * parte de la frase y el segundo la segunda parte de la frase.
	 * 
	 * @param sParagraphText
	 * @return Array que almacena un p�rrafo del texto original.
	 */
	private static String[][] processParagraph(String sParagraphText) {

		// Detectamos si se necesita pulsaci�n de bot�n o no.
		String symbolPagesSeparator = Constants.config_ps2
				.get(Constants.SYMBOL_USER_PULSE_PLEASE);
		if (sParagraphText.indexOf(symbolPagesSeparator) < 0
				&& sParagraphText.indexOf(Constants.config_ps2
						.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) > 0) {
			symbolPagesSeparator = Constants.config_ps2
					.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE);
		}

		String[] sPreProcessParagraphText = sParagraphText
				.split(symbolPagesSeparator);
		String[][] sProcessPointerText = null;
		// No encuentra ning�n simbolo de divisi�n y almacena la frase de la
		// siguiente manera:
		// 1 [contenido_parrafo_completo][null]
		// 2 [marca_fin_parrafo][null]
		// if (sPreProcessParagraphText.length == 1) {
		// sProcessPointerText = new String[2][LINES_PER_SENTENCE];
		// sProcessPointerText[0][0] = sPreProcessParagraphText[0].substring(
		// 0, sPreProcessParagraphText[0].indexOf(config_ps2
		// .get(SYMBOL_SEPARATOR_PARAGRAPH)));
		// sProcessPointerText[1][0] = config_ps2
		// .get(SYMBOL_SEPARATOR_PARAGRAPH);
		// } else {
		// Encuentra mas de un simbolo de divisi�n por lo que se almacena:
		// i [Linea_superior_frase][(Linea_inferior_frase)]
		// N [splitSymbol+(caracteres_aleatorios)][marca_fin_parrafo]
		sProcessPointerText = new String[sPreProcessParagraphText.length][Constants.LINES_PER_SENTENCE];
		int i = 0;
		for (; i < sPreProcessParagraphText.length - 1; i++) {
			String sCurrentText = sPreProcessParagraphText[i];
			String[] sSplitTextPerLines = sCurrentText
					.split(Constants.config_ps2
							.get(Constants.SYMBOL_CARRY_RETURN));
			boolean bSaltoLinea = sSplitTextPerLines.length == Constants.LINES_PER_SENTENCE ? true
					: false;
			sProcessPointerText[i][0] = sSplitTextPerLines[0];
			sProcessPointerText[i][1] = bSaltoLinea ? sSplitTextPerLines[1]
					: null;
		}
		sProcessPointerText[i][0] = symbolPagesSeparator
				+ sPreProcessParagraphText[i]
						.substring(
								0,
								sPreProcessParagraphText[i]
										.indexOf(Constants.config_ps2
												.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH)));
		sProcessPointerText[i][1] = Constants.config_ps2
				.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH);
		// }
		return sProcessPointerText;

	}

	/**
	 * Almacena una colecci�n de elementos cuya key de localizaci�n es el texto
	 * original y el valor el texto traducido.
	 * 
	 * @param brHelper
	 * @return Mapa que almacena la informaci�n del fichero de apoyo brHelper.
	 * @throws IOException
	 */
	private static Map<String, String> loadHelperTextToMap(String sPathName,
			String sHelperTextFileName) {
		Map<String, String> mTranslateMap = null;
		BufferedReader brHelper = null;
		try {
			brHelper = new BufferedReader(new FileReader(new File(sPathName,
					sHelperTextFileName)));
			while (brHelper.ready()) {
				String sCurrentTranslate = brHelper.readLine();
				if (sCurrentTranslate != null && !sCurrentTranslate.equals("")) {
					String sCurrentTranslateValue = "->";
					String sCurrentTranslateValueKey = sCurrentTranslate
							.substring(0, 1).toUpperCase();
					if (mTranslateMap == null)
						mTranslateMap = new HashMap<String, String>();
					if (mTranslateMap.containsKey(sCurrentTranslateValueKey)) {
						sCurrentTranslateValue = mTranslateMap
								.get(sCurrentTranslateValueKey)
								+ "\n->";
					}
					sCurrentTranslateValue += sCurrentTranslate
							.split(Constants.SYMBOL_TRANSLATE_HELPER_TEXT)[1];
					mTranslateMap.put(sCurrentTranslateValueKey,
							sCurrentTranslateValue);
				}
			}
		} catch (IOException ioe) {
			System.out.println("WARNING: Problemas al leer el fichero "
					+ sPathName + File.separatorChar + sHelperTextFileName
					+ ". No se utilizar� fichero de apoyo.");
		} finally {
			try {
				if (brHelper != null)
					brHelper.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return mTranslateMap;
	}

	/**
	 * M�todo que recupera el �ltimo parrafo por el que nos quedamos y devuelve
	 * el siguiente por el que devemos continuar.
	 * 
	 * @param fInputStream
	 * @return
	 * @throws IOException
	 */
	private static int calculateInitialParagraph(String sPathName,
			String sOutputFileNameComplete) {

		BufferedReader brIntermediate = null;
		int nInitialParagraph = 0;
		try {
			brIntermediate = new BufferedReader(new FileReader(new File(
					sPathName, sOutputFileNameComplete)));
			String sLine = "";
			String sMark = "";
			while (brIntermediate.ready()) {
				sLine = brIntermediate.readLine();
				if (sLine.startsWith(Constants.MARK_FINISH_PARAGRAPH)) {
					sMark = sLine;
				}
			}
			if (sMark != null && !sMark.equals("")) {
				nInitialParagraph = Integer.parseInt(sMark.substring(
						Constants.MARK_FINISH_PARAGRAPH.length(), sMark
								.indexOf(']')));
			}
		} catch (FileNotFoundException fnfe) {
			System.out.println("\nEl fichero " + sPathName + File.separatorChar
					+ sOutputFileNameComplete
					+ " no existe. Se creara para almacenar la traducci�n.\n");
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer el fichero "
					+ sPathName + File.separatorChar + sOutputFileNameComplete
					+ ". Vuelva a intentarlo.");
		} finally {
			try {
				if (brIntermediate != null)
					brIntermediate.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return nInitialParagraph;
	}

	/**
	 * M�todo que va solicitando al usuario el texto traducido.
	 * 
	 * @param fOutPut
	 * @throws IOException
	 */
	private static int translate(String sPathName,
			String sIntermediateOutputFileNameComplete,
			List<String[][]> lParagraphs, Map<String, String> mTranslateMap,
			BufferedReader keyboard, int nInitialParagraph, int nLineLenght) {

		PrintStream psIntermediate = null;
		boolean bSalir = false;
		int nParagraph = 0;
		try {
			File fIntermediateOutput = new File(sPathName,
					sIntermediateOutputFileNameComplete);
			if (fIntermediateOutput.exists()) {
				psIntermediate = new PrintStream(new BufferedOutputStream(
						new FileOutputStream(fIntermediateOutput, true)));
			} else {
				psIntermediate = new PrintStream(new BufferedOutputStream(
						new FileOutputStream(fIntermediateOutput)));
			}
			String sIntermediateText = "";
			String asIntermediateTextAux[] = new String[3];
			asIntermediateTextAux[0] = "";
			asIntermediateTextAux[1] = "";
			asIntermediateTextAux[2] = "";
			String[][] currentPages;
			boolean bCorrectTranslate = false;
			for (; nParagraph < lParagraphs.size() && !bSalir; nParagraph++) {
				System.out
						.println("\n\n_______________________________ INICIO DEL P�RRAFO "
								+ (nInitialParagraph + nParagraph + 1)
								+ " DE "
								+ (nInitialParagraph + lParagraphs.size())
								+ " _______________________________");
				while (!bCorrectTranslate) {
					currentPages = lParagraphs.get(nParagraph);
					String symbolPulse = "";
					if (currentPages[currentPages.length - 1][0]
							.startsWith(Constants.config_ps2
									.get(Constants.SYMBOL_USER_PULSE_PLEASE)))
						symbolPulse = Constants.SYMBOL_USER_PULSE_PLEASE;
					else if (currentPages[currentPages.length - 1][0]
							.startsWith(Constants.config_ps2
									.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)))
						symbolPulse = Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE;
					for (int nCurrentPage = 0; nCurrentPage < currentPages.length
							&& !bSalir; nCurrentPage++) {
						if (currentPages[nCurrentPage][0]
								.startsWith(Constants.config_ps2
										.get(symbolPulse))
								&& currentPages[nCurrentPage][1] != null
								&& currentPages[nCurrentPage][1]
										.equals(Constants.config_ps2
												.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {
							// Caso: Si que se ha encontrado un splitSymbol
							// [USER_PULSE_PLEASE|NO_NEED_USER_PULSE_PLEASE]
							// Necesitamos introducir los posibles simbolos
							// extra�os que aparezcan entre el splitSymbol y el
							// final de p�rrafo
							System.out
									.println("_______________________________ FIN DEL P�RRAFO "
											+ (nInitialParagraph + nParagraph + 1)
											+ " DE "
											+ (nInitialParagraph + lParagraphs
													.size())
											+ " _______________________________"
											+ "\n\n");
							if (currentPages[nCurrentPage][0]
									.indexOf(Constants.config_ps2
											.get(symbolPulse)) >= 0) {
								String sAditionalInformation = currentPages[nCurrentPage][0]
										.substring(currentPages[nCurrentPage][0]
												.indexOf(Constants.config_ps2
														.get(symbolPulse))
												+ Constants.config_ps2.get(
														symbolPulse).length());
								if (!sAditionalInformation.equals("")) {
									sIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE
											+ sAditionalInformation
											+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE
											+ Constants.MARK_NO_SPACING_IN_PREVIOUS_TEXT
											+ "\n";
								}
							}
							sIntermediateText += Constants.MARK_FINISH_PARAGRAPH
									+ (nInitialParagraph + nParagraph + 1)
									+ "]" + "\n\n";
						} else {
							System.out.println(currentPages[nCurrentPage][0]);
							if (currentPages[nCurrentPage][1] != null)
								System.out
										.println(currentPages[nCurrentPage][1]);
							// COMPROBACIONES

							// TIPO TEXTO (SECCION (PAGINA INICIAL) O PAGINA)
							int nPositionStartText = 0;
							boolean bInvalidPosition = true;
							while (bInvalidPosition) {
								nPositionStartText = insertInt(keyboard,
										"Introduzca la posici�n del inicio del texto (posici�n inicial "
												+ nPositionStartText + "): ");
								if (nPositionStartText > currentPages[nCurrentPage][0]
										.length()) {
									System.out
											.println("Posici�n incorrecta, vuelva a intentarlo");
									bInvalidPosition = true;
								} else {
									bInvalidPosition = false;
								}
								asIntermediateTextAux[0] += Constants.MARK_INIT_HEADER
										+ currentPages[nCurrentPage][0]
												.substring(0,
														nPositionStartText)
										+ Constants.MARK_FINISH_HEADER;
							}

							// PAGINA CON SALTO DE LINEA
							boolean bCarryReturn = (currentPages[nCurrentPage][1] != null) ? true
									: false;
							if (bCarryReturn) {
								System.out
										.println("WARNING: El texto contiene salto de l�nea, asegurese de introducir un salto de l�nea");
							}

							// MARCADO DE TEXTO
							boolean bRedText = (currentPages[nCurrentPage][0]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_RED_TEXT)) >= 0 || (bCarryReturn && currentPages[nCurrentPage][1]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_RED_TEXT)) >= 0)) ? true
									: false;
							if (bRedText) {
								System.out
										.println("WARNING: El texto contiene marcado de palabras, asegurese de introducirlo.");
							}

							// TEXTO PEQUE�O
							boolean bSmallText = (currentPages[nCurrentPage][0]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT)) >= 0 || (bCarryReturn && currentPages[nCurrentPage][1]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT)) >= 0)) ? true
									: false;
							if (bSmallText) {
								System.out
										.println("WARNING: El texto contiene partes en letra peque�a, asegurese de introducirlo.");
							}

							// TEXTO GRANDE
							boolean bBigText = (currentPages[nCurrentPage][0]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_BIG_TEXT)) >= 0 || (bCarryReturn && currentPages[nCurrentPage][1]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_PREFFIX_BIG_TEXT)) >= 0)) ? true
									: false;
							if (bBigText) {
								System.out
										.println("WARNING: El texto contiene partes en letra grande, asegurese de introducirlo.");
							}

							// TEXTO OPCIONES
							boolean bOptionText = (currentPages[nCurrentPage][0]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_OPTION_TEXT_QUESTION)) >= 0 || (bCarryReturn && currentPages[nCurrentPage][1]
									.indexOf(Constants.config_ps2
											.get(Constants.SYMBOL_OPTION_TEXT_QUESTION)) >= 0)) ? true
									: false;
							if (bOptionText) {
								System.out
										.println("WARNING: La siguiente frase es especial. Contiene varias opciones.");
							}

							// MOSTRAMOS LOS TEXTOS APOYO
							if (mTranslateMap != null) {
								if (currentPages[nCurrentPage][0].length() > nPositionStartText
										&& mTranslateMap
												.containsKey(currentPages[nCurrentPage][0]
														.substring(
																nPositionStartText,
																nPositionStartText + 1)
														.toUpperCase())) {
									System.out.println("Textos de apoyo:");
									System.out
											.println(mTranslateMap
													.get(currentPages[nCurrentPage][0]
															.substring(
																	nPositionStartText,
																	nPositionStartText + 1)
															.toUpperCase()));
								}
							}
							boolean bSpacingText;
							boolean bEndLine;
							boolean bEndPage = false;
							boolean bError = true;
							boolean bAditionalText = false;

							String sPS2UserTextAux = "";
							int nPS2PositionStartSmallText = -1;
							int nPS2PositionStartBigText = -1;

							String sWIIUserTextAux = "";
							int nWIIPositionStartSmallText = -1;
							int nWIIPositionStartBigText = -1;

							try {
								while ((!bEndPage || bError) && !bSalir) {
									bError = false;
									bSpacingText = true;
									bEndLine = false;
									bEndPage = false;

									String sPS2PreText = "";
									String sPS2UserText = "";
									String sPS2Exclamation = "";
									String sPS2PostText = "";

									String sWIIPreText = "";
									String sWIIUserText = "";
									String sWIIExclamation = "";
									String sWIIPostText = "";

									if (nPositionStartText < currentPages[nCurrentPage][0]
											.length()) {
										System.out
												.println("Introduzca la traducci�n y pulse intro para ver acciones:");
										sPS2UserText = keyboard.readLine();
										sWIIUserText = sPS2UserText;
										if (!sPS2UserText.equals("")) {
											asIntermediateTextAux[1] += Constants.MARK_INIT_TEXT_TO_TRANSLETE
													+ sPS2UserText
													+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
										}
									}
									if (nPositionStartText > 0) {
										sPS2PreText += currentPages[nCurrentPage][0]
												.substring(0,
														nPositionStartText);
										sWIIPreText += formatWIIPreText(currentPages[nCurrentPage][0]
												.substring(0,
														nPositionStartText));
									}
									boolean bAccionCorrecta;
									do {
										bAccionCorrecta = true;
										System.out
												.println("Acciones disponibles: ");
										if (bRedText) {
											System.out
													.println("\t1.- Iniciar marcado de texto.");
											System.out
													.println("\t2.- Finalizar marcado de texto.");
										}
										if (bCarryReturn) {
											System.out
													.println("\t3.- Introducir salto de l�nea.");
										}
										if (!bCarryReturn || bAditionalText) {
											System.out
													.println("\t4.- Finalizar p�gina.");
										}
										System.out
												.println("\t5.- Introducir texto sin espaciado.");
										System.out
												.println("\t6.- Introducir texto con espaciado.");
										if (bSmallText) {
											System.out
													.println("\t7.- Iniciar texto peque�o.");
											if (!bCarryReturn || bAditionalText) {
												System.out
														.println("\t8.- Finalizar texto peque�o y p�gina.");
											}
										}
										if (bBigText) {
											System.out
													.println("\t9.- Iniciar texto grande.");
											if (!bCarryReturn || bAditionalText) {
												System.out
														.println("\t10.- Finalizar texto grande y p�gina.");
											}
										}
										System.out
												.println("\t11.- Insertar exclamaci�n.");
										if (bOptionText) {
											System.out
													.println("\t12.- Gestionar texto con opciones.");
										}
										System.out.println("\t13.- Salir.");
										int nAccion = insertInt(keyboard,
												"Acci�n a realizar: ");
										switch (nAccion) {
										case 1:
											if (bRedText) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_PREFFIX_RED_TEXT);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_PREFFIX_RED_TEXT);
												asIntermediateTextAux[2] += Constants.MARK_INIT_RED_TEXT;
											} else
												bAccionCorrecta = false;
											break;
										case 2:
											if (bRedText) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_SUFFIX_RED_TEXT);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_SUFFIX_RED_TEXT);
												asIntermediateTextAux[2] += Constants.MARK_FINISH_RED_TEXT;
											} else
												bAccionCorrecta = false;
											break;
										case 3:
											if (bCarryReturn) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_CARRY_RETURN);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_CARRY_RETURN);
												asIntermediateTextAux[2] += Constants.MARK_CARRY_RETURN
														+ "\n";
												bEndLine = true;
											} else
												bAccionCorrecta = false;
											break;
										case 4:
											if (!bCarryReturn || bAditionalText) {
												sPS2PostText = Constants.config_ps2
														.get(symbolPulse);
												sWIIPostText = Constants.config_wii
														.get(symbolPulse);
												if (symbolPulse
														.equals(Constants.SYMBOL_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_USER_PULSE_PLEASE;
												} else if (symbolPulse
														.equals(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
												} else {
													asIntermediateTextAux[2] += "";
												}
												asIntermediateTextAux[2] += "\n\n";
												bEndPage = true;
											} else
												bAccionCorrecta = false;
											break;
										case 5:
											bSpacingText = false;
											if (!sPS2UserText.equals("")) {
												asIntermediateTextAux[2] += Constants.MARK_NO_SPACING_IN_PREVIOUS_TEXT;
												System.out
														.println("WARNING: Debe introducir la versi�n WII del texto sin espaciado:");
												sWIIUserText = keyboard
														.readLine();
											}
											break;
										case 6:
											break;
										case 7:
											if (bSmallText) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT);
												asIntermediateTextAux[2] += Constants.MARK_INIT_SMALL_TEXT;
											} else
												bAccionCorrecta = false;
											break;
										case 8:
											if (bSmallText
													&& (!bCarryReturn || bAditionalText)) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT)
														+ Constants.config_ps2
																.get(symbolPulse);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT)
														+ Constants.config_wii
																.get(symbolPulse);
												asIntermediateTextAux[2] += Constants.MARK_FINISH_SMALL_TEXT;
												if (symbolPulse
														.equals(Constants.SYMBOL_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_USER_PULSE_PLEASE;
												} else if (symbolPulse
														.equals(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
												} else {
													asIntermediateTextAux[2] += "";
												}
												asIntermediateTextAux[2] += "\n\n";
												bEndPage = true;
											} else
												bAccionCorrecta = false;
											break;
										case 9:
											if (bBigText) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_PREFFIX_BIG_TEXT);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_PREFFIX_BIG_TEXT);
												asIntermediateTextAux[2] += Constants.MARK_INIT_BIG_TEXT;
											} else
												bAccionCorrecta = false;
											break;
										case 10:
											if (bBigText
													&& (!bCarryReturn || bAditionalText)) {
												sPS2PostText = Constants.config_ps2
														.get(Constants.SYMBOL_SUFFIX_BIG_TEXT)
														+ Constants.config_ps2
																.get(symbolPulse);
												sWIIPostText = Constants.config_wii
														.get(Constants.SYMBOL_SUFFIX_BIG_TEXT)
														+ Constants.config_wii
																.get(symbolPulse);
												asIntermediateTextAux[2] += Constants.MARK_FINISH_BIG_TEXT;
												if (symbolPulse
														.equals(Constants.SYMBOL_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_USER_PULSE_PLEASE;
												} else if (symbolPulse
														.equals(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
												} else {
													asIntermediateTextAux[2] = "";
												}
												asIntermediateTextAux[2] += "\n\n";
												bEndPage = true;
											} else
												bAccionCorrecta = false;
											break;
										case 11:
											sPS2Exclamation = selectExclamations(keyboard);
											sWIIExclamation = sPS2Exclamation;
											asIntermediateTextAux[2] += Constants.MARK_INIT_TEXT_TO_TRANSLETE
													+ sPS2Exclamation
													+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
											break;
										case 12:
											if (bOptionText) {
												asIntermediateTextAux[1] = processOptions(keyboard);
												if (symbolPulse
														.equals(Constants.SYMBOL_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_USER_PULSE_PLEASE;
												} else if (symbolPulse
														.equals(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)) {
													asIntermediateTextAux[2] += Constants.MARK_NO_NEED_USER_PULSE_PLEASE;
												} else {
													asIntermediateTextAux[2] += "";
												}
												asIntermediateTextAux[2] += "\n\n";
												bEndPage = true;
											} else
												bAccionCorrecta = false;
											break;
										case 13:
											boolean bOptionCorrect = false;
											while (!bOptionCorrect) {
												int nOption = insertInt(
														keyboard,
														"WARNING: Los cambios realizados desde el �ltimo p�rrafo traducido completamente no se guardar�n.\n�Deseas dejar de traducir (Si=1\\No=0)?");
												if (nOption == 0
														|| nOption == 1) {
													bOptionCorrect = true;
													if (nOption == 1)
														bSalir = true;
												}
											}
											break;
										}
										if (!bAccionCorrecta) {
											System.err
													.println("ERROR: Acci�n no disponible.");

										}
									} while (!bAccionCorrecta);
									if (!bSalir) {
										if (bSpacingText) {
											sPS2UserText = applySpacingTextPS2(sPS2UserText)
													+ applySpacingTextPS2(sPS2Exclamation);
											sWIIUserText = applySpacingTextWII(sWIIUserText)
													+ applySpacingTextWII(sWIIExclamation);
										}
										sPS2UserTextAux += sPS2UserText;
										sWIIUserTextAux += sWIIUserText;
										int nPS2UserTextAuxLength = sPS2UserTextAux
												.length();
										if (nPS2PositionStartSmallText > -1
												&& !sPS2PostText
														.equals(Constants.config_ps2
																.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT))) {
											nPS2UserTextAuxLength = sPS2UserTextAux
													.substring(0,
															nPS2PositionStartSmallText)
													.length()
													+ new Double(
															new Double(
																	sPS2UserTextAux
																			.substring(
																					nPS2PositionStartSmallText)
																			.length())
																	.doubleValue()
																	* Constants.DIFF_SMALL_TEXT)
															.intValue();
										}
										if (nPS2PositionStartBigText > -1
												&& !sPS2PostText
														.equals(Constants.config_ps2
																.get(Constants.SYMBOL_PREFFIX_BIG_TEXT))) {
											nPS2UserTextAuxLength = sPS2UserTextAux
													.substring(0,
															nPS2PositionStartBigText)
													.length()
													+ new Double(
															new Double(
																	sPS2UserTextAux
																			.substring(
																					nPS2PositionStartBigText)
																			.length())
																	.doubleValue()
																	* Constants.DIFF_BIG_TEXT)
															.intValue();
										}
										int nWIIUserTextAuxLength = sWIIUserTextAux
												.length();
										if (nWIIPositionStartSmallText > -1
												&& !sWIIPostText
														.equals(Constants.config_wii
																.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT))) {
											nWIIUserTextAuxLength = sWIIUserTextAux
													.substring(0,
															nWIIPositionStartSmallText)
													.length()
													+ new Double(
															new Double(
																	sWIIUserTextAux
																			.substring(
																					nWIIPositionStartSmallText)
																			.length())
																	.doubleValue()
																	* Constants.DIFF_SMALL_TEXT)
															.intValue();
										}
										if (nWIIPositionStartBigText > -1
												&& !sWIIPostText
														.equals(Constants.config_wii
																.get(Constants.SYMBOL_PREFFIX_BIG_TEXT))) {
											nWIIUserTextAuxLength = sWIIUserTextAux
													.substring(0,
															nWIIPositionStartBigText)
													.length()
													+ new Double(
															new Double(
																	sWIIUserTextAux
																			.substring(
																					nWIIPositionStartBigText)
																			.length())
																	.doubleValue()
																	* Constants.DIFF_BIG_TEXT)
															.intValue();
										}

										System.out
												.println("Tama�o del texto introducido (WARNING: Tama�o Peque�o (x"
														+ Constants.DIFF_SMALL_TEXT
														+ ") | Tama�o Grande (x"
														+ Constants.DIFF_BIG_TEXT
														+ ")):");
										System.out.println("Texto PS2 -> "
												+ nPS2UserTextAuxLength);
										System.out.println("Texto WII -> "
												+ nWIIUserTextAuxLength);

										if (nPS2UserTextAuxLength > nLineLenght) {
											System.err
													.println("ERROR: El texto introducido es superior al permitido ("
															+ nLineLenght
															+ "). Reduzcalo.");

											String sEjemplo = "";
											if (nPS2PositionStartSmallText > -1
													&& !sPS2PostText
															.equals(Constants.config_ps2
																	.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT))) {
												if (sPS2UserTextAux
														.substring(0,
																nPS2PositionStartSmallText)
														.length() < nLineLenght) {
													sEjemplo = sPS2UserTextAux
															.substring(
																	0,
																	nPS2PositionStartSmallText
																			+ new Double(
																					new Double(
																							nLineLenght
																									- nPS2PositionStartSmallText)
																							.doubleValue()
																							* Constants.DIFF_BIG_TEXT)
																					.intValue());
												}
											} else if (nPS2PositionStartBigText > -1
													&& !sPS2PostText
															.equals(Constants.config_ps2
																	.get(Constants.SYMBOL_PREFFIX_BIG_TEXT))) {
												if (sPS2UserTextAux
														.substring(0,
																nPS2PositionStartBigText)
														.length() < nLineLenght) {
													sEjemplo = sPS2UserTextAux
															.substring(
																	0,
																	nPS2PositionStartBigText
																			+ new Double(
																					new Double(
																							nLineLenght
																									- nPS2PositionStartBigText)
																							.doubleValue()
																							* Constants.DIFF_SMALL_TEXT)
																					.intValue());
												}
											} else {
												sEjemplo = sPS2UserTextAux
														.substring(0,
																nLineLenght);
											}
											System.out.println("Ejemplo: "
													+ sEjemplo);
											sPS2UserTextAux = sPS2UserTextAux
													.substring(
															0,
															sPS2UserTextAux
																	.length()
																	- sPS2UserText
																			.length());
											bError = true;
										} else {
											if (sPS2PostText
													.equals((Constants.config_ps2
															.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT)))) {
												nPS2PositionStartSmallText = sPS2UserTextAux
														.length();
											} else if (sPS2PostText
													.equals((Constants.config_ps2
															.get(Constants.SYMBOL_PREFFIX_BIG_TEXT)))) {
												nPS2PositionStartBigText = sPS2UserTextAux
														.length();
											}
											if (bEndLine || bEndPage) {
												sPS2UserTextAux = "";
												if (nPS2PositionStartSmallText > -1)
													nPS2PositionStartSmallText = 0;
												else if (nPS2PositionStartBigText > -1)
													nPS2PositionStartBigText = 0;
											}
										}
										if (nWIIUserTextAuxLength > nLineLenght) {
											System.err
													.println("ERROR: El texto introducido es superior al permitido ("
															+ nLineLenght
															+ "). Reduzcalo.");

											String sEjemplo = "";
											if (nWIIPositionStartSmallText > -1
													&& !sWIIPostText
															.equals(Constants.config_wii
																	.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT))) {
												if (sWIIUserTextAux
														.substring(0,
																nWIIPositionStartSmallText)
														.length() < nLineLenght) {
													sEjemplo = sWIIUserTextAux
															.substring(
																	0,
																	nWIIPositionStartSmallText
																			+ new Double(
																					new Double(
																							nLineLenght
																									- nWIIPositionStartSmallText)
																							.doubleValue()
																							* Constants.DIFF_BIG_TEXT)
																					.intValue());
												}
											} else if (nWIIPositionStartBigText > -1
													&& !sWIIPostText
															.equals(Constants.config_wii
																	.get(Constants.SYMBOL_PREFFIX_BIG_TEXT))) {
												if (sWIIUserTextAux
														.substring(0,
																nWIIPositionStartBigText)
														.length() < nLineLenght) {
													sEjemplo = sWIIUserTextAux
															.substring(
																	0,
																	nWIIPositionStartBigText
																			+ new Double(
																					new Double(
																							nLineLenght
																									- nWIIPositionStartBigText)
																							.doubleValue()
																							* Constants.DIFF_SMALL_TEXT)
																					.intValue());
												}
											} else {
												sEjemplo = sWIIUserTextAux
														.substring(0,
																nLineLenght);
											}
											System.out.println("Ejemplo: "
													+ sEjemplo);
											sWIIUserTextAux = sWIIUserTextAux
													.substring(
															0,
															sWIIUserTextAux
																	.length()
																	- sWIIUserText
																			.length());
											bError = true;
										} else {
											if (sWIIPostText
													.equals((Constants.config_wii
															.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT))))
												nWIIPositionStartSmallText = sWIIUserTextAux
														.length();
											else if (sWIIPostText
													.equals((Constants.config_wii
															.get(Constants.SYMBOL_PREFFIX_BIG_TEXT))))
												nWIIPositionStartBigText = sWIIUserTextAux
														.length();
											if (bEndLine || bEndPage) {
												sWIIUserTextAux = "";
												if (nWIIPositionStartSmallText > -1)
													nWIIPositionStartSmallText = 0;
												else if (nWIIPositionStartBigText > -1)
													nWIIPositionStartBigText = 0;
											}
										}
										if (!bError) {
											System.out
													.println("Traducci�n PS2:\n"
															+ sPS2PreText
															+ sPS2UserText
															+ sPS2PostText
															+ "\n");
											System.out
													.println("Traducci�n WII:\n"
															+ sWIIPreText
															+ sWIIUserText
															+ sWIIPostText
															+ "\n\n");
											sIntermediateText += asIntermediateTextAux[0]
													+ asIntermediateTextAux[1]
													+ asIntermediateTextAux[2];
											if (bEndLine) {
												bCarryReturn = false;
											}
											nPositionStartText = 0;
											if (bEndPage) {
												bAditionalText = (insertInt(
														keyboard,
														"�Desea introducir alguna frase adicional (Si=1\\No=0)?.") == 1) ? true
														: false;
												if (bAditionalText) {
													bCarryReturn = true;
													bEndPage = false;
													sIntermediateText += "\n\n"
															+ Constants.MARK_INIT_HEADER
															+ Constants.config_ps2
																	.get(Constants.SYMBOL_END_SENTENCE)
															+ Constants.MARK_FINISH_HEADER;
												}
											}
											asIntermediateTextAux[0] = "";
										}
										asIntermediateTextAux[1] = "";
										asIntermediateTextAux[2] = "";
									}
								}
							} catch (IOException e) {
								System.err
										.println("ERROR: Problemas en la captura del texto.");

							}
						}
					}
					if (!bSalir) {
						String sIntermediateTextDivided[] = sIntermediateText
								.split("\n");
						for (int i = 0; i < sIntermediateTextDivided.length; i++) {
							psIntermediate.print(sIntermediateTextDivided[i]);
							psIntermediate.println();
						}
						sIntermediateText = "";
					}
					bCorrectTranslate = true;
				}
				bCorrectTranslate = false;
			}
		} catch (IOException ioe) {
			System.err.println("ERROR: Problemas al leer el fichero "
					+ sPathName + File.separatorChar
					+ sIntermediateOutputFileNameComplete
					+ ". Vuelva a intentarlo.");

		} catch (Exception e) {
			System.err.println("ERROR DESCONOCIDO.");
			System.err.println(e.getMessage());

		} finally {
			if (psIntermediate != null)
				psIntermediate.close();
		}
		// if (bSalir)
		// nParagraph = -1;
		return nParagraph;
	}

	/**
	 * M�todo auxiliar para controlar que el usuario introduce realmente un
	 * entero por pantalla.
	 * 
	 * @param keyboard
	 * @param texto
	 * @return
	 */
	private static int insertInt(BufferedReader keyboard, String texto) {
		int nResultado = 0;
		boolean bInvalidPosition = true;
		while (bInvalidPosition) {
			System.out.println(texto);
			try {
				nResultado = Integer.parseInt(keyboard.readLine());
				bInvalidPosition = false;
			} catch (NumberFormatException e) {
				System.err.println("\nERROR: Debe introducir un n�mero.");

			} catch (IOException e) {
				System.err
						.println("\nERROR: No se detect� correctamente el texto.");

			}
		}
		return nResultado;
	}

	/**
	 * M�todo que introduce espacios en el texto que se le pasa como par�metro.
	 * Valido para la plataforma PS2.
	 * 
	 * @param sUserText
	 * @return
	 */
	private static String applySpacingTextPS2(String sUserText) {
		String sSpacedUserText = "";
		if (!sUserText.equals("")) {
			for (int nUserTextPos = 0; nUserTextPos < sUserText.length(); nUserTextPos++) {
				sSpacedUserText += sUserText.charAt(nUserTextPos) + " ";
			}
		}
		return sSpacedUserText;
	}

	/**
	 * M�todo que introduce espacios en el texto que se le pasa como par�metro.
	 * Valido para la plataforma WII.
	 * 
	 * @param sUserText
	 * @return
	 */
	private static String applySpacingTextWII(String sUserText) {
		String sSpacedUserText = "";
		if (!sUserText.equals("")) {
			// sSpacedUserText += sUserText.charAt(0);
			for (int nUserTextPos = 0; nUserTextPos < sUserText.length(); nUserTextPos++) {
				sSpacedUserText += " " + sUserText.charAt(nUserTextPos);
			}
		}
		return sSpacedUserText;
	}

	/**
	 * Si hemos traducido todos los p�rrafos generamos un fichero de exportaci�n
	 * para la adaptaci�n a una plataforma u otra. Genera un fichero que mapea
	 * los parrafos originales con los traducidos.
	 * 
	 * @param sPathName
	 * @param sOriginalTextFileNameComplete
	 * @param sTranslateTextFileNameComplete
	 * @param sExportFileNameComplete
	 *            Este fichero se eliminar� si existe, es decir, se regenerar�.
	 * @param nTotalParagraphs
	 */
	private static void export(String sPathName,
			String sOriginalTextFileNameComplete,
			String sTranslateTextFileNameComplete,
			String sExportFileNameComplete, int nTotalParagraphs) {

		FileInputStream fOriginalTextStream = null;
		FileInputStream fTranslateTextStream = null;
		FileOutputStream fExportStream = null;
		try {
			fOriginalTextStream = new FileInputStream(new File(sPathName,
					sOriginalTextFileNameComplete));
			fTranslateTextStream = new FileInputStream(new File(sPathName,
					sTranslateTextFileNameComplete));

			char cCurrentChar;
			String sOriginalText = "";
			String sTranslateText = "";
			String sExportText = "";

			String[] sOriginalTextParagraphs = new String[nTotalParagraphs];
			int nParagraph = 0;
			while (fOriginalTextStream.available() > 0) {
				cCurrentChar = (char) fOriginalTextStream.read();
				sOriginalText += cCurrentChar;
				if (sOriginalText.endsWith(Constants.config_ps2
						.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {
					sOriginalTextParagraphs[nParagraph++] = sOriginalText;
					sOriginalText = "";
				}
			}
			String[] sTranslateTextParagraphs = new String[nTotalParagraphs];
			nParagraph = 0;
			while (fTranslateTextStream.available() > 0) {
				cCurrentChar = (char) fTranslateTextStream.read();
				sTranslateText += cCurrentChar;
				if (sTranslateText.endsWith(Constants.config_ps2
						.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH))) {
					sTranslateTextParagraphs[nParagraph++] = sTranslateText;
					sTranslateText = "";
				}
			}
			if (sOriginalTextParagraphs.length == sTranslateTextParagraphs.length) {
				for (nParagraph = 0; nParagraph < sOriginalTextParagraphs.length; nParagraph++) {
					sExportText += sOriginalTextParagraphs[nParagraph] + "\n"
							+ sTranslateTextParagraphs[nParagraph] + "\n\n";
				}
				if (sExportText != null && !sExportText.equals("")) {
					fExportStream = new FileOutputStream(new File(sPathName,
							sExportFileNameComplete));
					for (int nChar = 0; nChar < sExportText.length(); nChar++) {
						fExportStream.write(sExportText.charAt(nChar));
					}
				}
				System.out
						.println("-> Regeneraci�n de texto exportado completa: "
								+ sExportFileNameComplete + "\n");
			}

		} catch (IOException ioe) {
			System.err
					.println("\nERROR: Problemas al leer ficheros. Vuelva a intentarlo.");
			System.exit(0);
		} finally {
			try {
				if (fOriginalTextStream != null)
					fOriginalTextStream.close();
				if (fTranslateTextStream != null)
					fTranslateTextStream.close();
				if (fExportStream != null)
					fExportStream.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
	}

	private static String selectExclamations(BufferedReader keyboard) {
		String sExclamation = "";
		if (Constants.exclamations == null) {
			ResourceBundle bundle = ResourceBundle.getBundle("Exclamations");
			Constants.exclamations = new ArrayList<String[]>();
			for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements();) {
				String key = e.nextElement();
				String value = bundle.getString(key);
				Constants.exclamations.add(new String[] { key, value });
			}
		}
		String sListExclamationsToShow = "";
		for (int i = 0; i < Constants.exclamations.size(); i++) {
			sListExclamationsToShow += (i + 1) + ".- "
					+ Constants.exclamations.get(i)[0] + "->"
					+ Constants.SYMBOL_PREFFIX_EXCLAMATION
					+ Constants.exclamations.get(i)[1]
					+ Constants.SYMBOL_SUFFIX_EXCLAMATION;
			if ((i + 1) % 3 == 0) {
				sListExclamationsToShow += "\n";
			} else {
				sListExclamationsToShow += "\t\t";
			}
		}
		int nExclamation = 0;
		boolean bExclamtionExist = false;
		while (!bExclamtionExist) {
			nExclamation = insertInt(keyboard, sListExclamationsToShow);
			if (nExclamation > 0
					&& nExclamation < Constants.exclamations.size() + 1) {
				sExclamation = Constants.SYMBOL_PREFFIX_EXCLAMATION
						+ Constants.exclamations.get(nExclamation - 1)[1]
						+ Constants.SYMBOL_SUFFIX_EXCLAMATION;
				bExclamtionExist = true;
			}
		}
		return sExclamation;
	}

	private static String formatWIIPreText(String sWIIPreText) {
		if (sWIIPreText.length() > 0) {
			String sWIIPreTextFormated = "";
			String[] sPreTextDivided = sWIIPreText.split("[.]");
			if (sPreTextDivided.length > 1) {
				for (int i = 0; i < sPreTextDivided.length; i++) {
					if (sPreTextDivided[i].length() > 0) {
						if (i == 0)
							sWIIPreTextFormated += sPreTextDivided[i];
						else {
							if (sPreTextDivided[i].length() < 5)
								sWIIPreTextFormated += sPreTextDivided[i] + ".";
							else
								sWIIPreTextFormated += "." + sPreTextDivided[i];
						}
					}
				}
			} else
				sWIIPreTextFormated = sWIIPreText;
			return sWIIPreTextFormated;
		} else
			return sWIIPreText;

	}

	private static String processOptions(BufferedReader keyboard) {
		String sFormatIntermediateText = "";
		try {
			boolean bOptionCorrect = false;
			while (!bOptionCorrect) {
				int nOption = insertInt(
						keyboard,
						"�Desea utilizar las opciones por defecto -> 1 Pregunta, 1 Fila de Opciones, 2 Opciones por Fila (Si=1\\No=0)?");
				if (nOption == 0 || nOption == 1) {
					bOptionCorrect = true;
					int nRows = 1;
					int nOptions = 2;
					if (nOption == 0) {
						nRows = insertInt(keyboard,
								"�Cuantas filas de opciones tiene?");
						nOptions = insertInt(keyboard,
								"�Cuantas opciones en cada fila?");
					}
					boolean bCenterOptions = true;
					boolean bQuestionCorrect = false;
					String sQuestion = "";
					while (!bQuestionCorrect) {
						System.out
								.println("Introduzca la pregunta sobre la que debes decidir:");
						sQuestion = keyboard.readLine();
						if (sQuestion.length() <= (Constants.N_LINE_LENGTH_DEFAULT / 2)) {
							bQuestionCorrect = true;
							sFormatIntermediateText += Constants.MARK_OPTION_TEXT_QUESTION
									+ Constants.MARK_INIT_TEXT_TO_TRANSLETE
									+ sQuestion
									+ Constants.MARK_FINISH_TEXT_TO_TRANSLETE
									+ Constants.MARK_CARRY_RETURN + "\n";
						} else {
							System.err
									.println("ERROR: El texto introducido es superior al permitido ("
											+ Constants.N_LINE_LENGTH_DEFAULT
											+ ")");
						}
					}
					boolean bOptionsCorrect;
					int nMaxLengthPerOption = sQuestion.length() / nOptions;
					int nOptionMinLength = 0;
					String sOptions[][];
					do {
						bOptionsCorrect = true;
						sOptions = new String[nRows][nOptions];
						int nTotalLength = 0;
						for (int i = 0; i < nRows && bOptionsCorrect; i++) {
							for (int j = 0; j < nOptions && bOptionsCorrect; j++) {
								nTotalLength = 0;
								System.out.println("Introduzca la opcion ["
										+ (i + 1) + "][" + (j + 1) + "]:");
								sOptions[i][j] = keyboard.readLine();
								nTotalLength += sOptions[i][j].length();
								if (nTotalLength > (Constants.N_LINE_LENGTH_DEFAULT / 2)) {
									bOptionsCorrect = false;
								}

								if (sOptions[i][j].length() > nMaxLengthPerOption) {
									bCenterOptions = false;
								}
								if (sOptions[i][j].length() < nOptionMinLength)
									nOptionMinLength = sOptions[i][j].length();
							}
						}
						if (!bOptionsCorrect) {
							System.err
									.println("Vuelva a introducir las opciones. Tama�o total: "
											+ (nTotalLength * 2));
						}
					} while (!bOptionsCorrect);
					if (bCenterOptions) {
						for (int i = 0; i < nRows; i++) {
							for (int j = 0; j < nOptions; j++) {
								int nTotalLength = 0;
								int nMiddleOption = sOptions[i][j].length() / 2;
								int nBlank = (nMaxLengthPerOption / 2)
										- nMiddleOption;
								sFormatIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE;
								while (nBlank > 0) {
									sFormatIntermediateText += " ";
									nBlank--;
									nTotalLength++;
								}
								sFormatIntermediateText += Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
								if (i == 0 && j == 0) {
									sFormatIntermediateText += Constants.MARK_OPTION_TEXT_DEFAULT;
								} else {
									sFormatIntermediateText += Constants.MARK_OPTION_TEXT;
								}
								sFormatIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE;
								sFormatIntermediateText += sOptions[i][j];
								nTotalLength += sOptions[i][j].length();
								while (nTotalLength < nMaxLengthPerOption) {
									sFormatIntermediateText += " ";
									nTotalLength++;
								}
								sFormatIntermediateText += Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
							}
							if (i != (nRows - 1))
								sFormatIntermediateText += Constants.MARK_CARRY_RETURN
										+ "\n";
						}
					} else {
						int nDefaultSeparation = nOptionMinLength / 3;
						if (nDefaultSeparation < 2)
							nDefaultSeparation = 2;
						for (int i = 0; i < nRows; i++) {
							for (int j = 0; j < nOptions; j++) {
								sFormatIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE;
								if (i == 0) {
									sFormatIntermediateText += " ";
								} else {
									for (int nAux = 0; nAux < nDefaultSeparation; nAux++)
										sFormatIntermediateText += " ";
								}
								sFormatIntermediateText += Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
								sFormatIntermediateText += Constants.MARK_INIT_TEXT_TO_TRANSLETE;
								if (i == 0 && j == 0) {
									sFormatIntermediateText += Constants.MARK_OPTION_TEXT_DEFAULT;
								} else {
									sFormatIntermediateText += Constants.MARK_OPTION_TEXT;
								}
								sFormatIntermediateText += sOptions[i][j];
								sFormatIntermediateText += Constants.MARK_FINISH_TEXT_TO_TRANSLETE;
							}
							if (i != (nRows - 1))
								sFormatIntermediateText += Constants.MARK_CARRY_RETURN
										+ "\n";
						}
					}
				}
			}
		} catch (IOException ioe) {
			System.err
					.println("Problemas en la inserci�n de datos por teclado.");
		}
		return sFormatIntermediateText;
	}

	public static boolean generateResult(String sPathName,
			String sIntermediateOutputFileNameComplete,
			String sOutputFileNameComplete, String sPlatform) {
		BufferedReader brIntermediate = null;
		FileOutputStream fosTranslate = null;
		boolean bCorrectGeneration = true;
		String sCurrentLine = "";
		int nLine = 0;
		try {
			boolean bGenerate = true;
			File fIntermediate = new File(sPathName,
					sIntermediateOutputFileNameComplete);
			brIntermediate = new BufferedReader(new FileReader(fIntermediate));

			File fOutput = new File(sPathName, sOutputFileNameComplete);
			if (fOutput.exists()
					&& fIntermediate.lastModified() < fOutput.lastModified())
				bGenerate = false;
			fosTranslate = new FileOutputStream(fOutput);

			if (bGenerate) {
				String sErrorDescription = null;
				String sTranslateText = "";
				int currentLineLength = Constants.N_LINE_LENGTH_DEFAULT;
				boolean bResetLineLength = false;
				while (brIntermediate.ready() && sErrorDescription == null) {
					sCurrentLine = brIntermediate.readLine();
					nLine++;
					int nTotalTextLength = 0;
					while (sCurrentLine.length() > 0
							&& sErrorDescription == null) {
						int nCurrentIndex = 0;
						boolean bFinish = false;
						while (!bFinish) {
							if (sCurrentLine.charAt(nCurrentIndex) == ']')
								bFinish = true;
							nCurrentIndex++;
						}
						bFinish = false;
						if (sCurrentLine.substring(0, nCurrentIndex).equals(
								Constants.MARK_INIT_HEADER)) {
							// MARCA CABECERAS
							int nInitIndex = nCurrentIndex;
							int nFinishIndex = nCurrentIndex;
							while (!bFinish) {
								if (sCurrentLine.substring(nCurrentIndex)
										.startsWith(
												Constants.MARK_FINISH_HEADER)) {
									bFinish = true;
									nFinishIndex = nCurrentIndex;
								}
								nCurrentIndex++;
							}
							bFinish = false;
							while (!bFinish) {
								if (sCurrentLine.charAt(nCurrentIndex) == ']')
									bFinish = true;
								nCurrentIndex++;
							}
							bFinish = false;
							String sHeader = sCurrentLine.substring(nInitIndex,
					 				nFinishIndex);
							// Eliminamos los espacios en blanco del principio
							boolean bHeaderWithoutWhitespaces = false;
							while (!bHeaderWithoutWhitespaces) {
								if (sHeader.startsWith(" "))
									sHeader = sHeader.substring(1);
								else
									bHeaderWithoutWhitespaces = true;
							}
							sTranslateText += sHeader;
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_INIT_TEXT_TO_TRANSLETE)) {
							// MARCA DE TEXTO LEGIBLE (CON ESPACIADO O SIN
							// ESPACIADO)
							int nInitIndex = nCurrentIndex;
							int nFinishIndex = nCurrentIndex;
							while (!bFinish) {
								if (sCurrentLine
										.substring(nCurrentIndex)
										.startsWith(
												Constants.MARK_FINISH_TEXT_TO_TRANSLETE)) {
									bFinish = true;
									nFinishIndex = nCurrentIndex;
								}
								nCurrentIndex++;
							}
							bFinish = false;
							while (!bFinish) {
								if (sCurrentLine.charAt(nCurrentIndex) == ']')
									bFinish = true;
								nCurrentIndex++;
							}
							bFinish = false;
							boolean bSpacing = true;
							if (sCurrentLine
									.substring(nCurrentIndex)
									.startsWith(
											Constants.MARK_NO_SPACING_IN_PREVIOUS_TEXT)) {
								while (!bFinish) {
									if (sCurrentLine.charAt(nCurrentIndex) == ']')
										bFinish = true;
									nCurrentIndex++;
								}
								bSpacing = false;
							}
							String sText = sCurrentLine.substring(nInitIndex,
									nFinishIndex);
							if (bSpacing) {
								String sSpacingText = (sPlatform.equals("PS2")) ? applySpacingTextPS2(sText)
										: applySpacingTextWII(sText);
								sTranslateText += sSpacingText;
								nTotalTextLength += sSpacingText.length();
							} else {
								sTranslateText += sText;
								nTotalTextLength += sText.length();
							}
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_CARRY_RETURN)) {
							// MARCA DE RETORNO DE CARRO
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_CARRY_RETURN)
									: Constants.config_wii
											.get(Constants.SYMBOL_CARRY_RETURN);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_USER_PULSE_PLEASE)) {
							// MARCA DE USUARIO, POR FAVOR PULSA
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_USER_PULSE_PLEASE)
									: Constants.config_wii
											.get(Constants.SYMBOL_USER_PULSE_PLEASE);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_INIT_RED_TEXT)) {
							// MARCA DE INICIO DE TEXTO EN ROJO
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_PREFFIX_RED_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_PREFFIX_RED_TEXT);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_FINISH_RED_TEXT)) {
							// MARCA DE FIN DE TEXTO EN ROJO
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_SUFFIX_RED_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_SUFFIX_RED_TEXT);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.startsWith(Constants.MARK_FINISH_PARAGRAPH)) {
							// MARCA DE FIN DE P�RRAFO
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH)
									: Constants.config_wii
											.get(Constants.SYMBOL_SEPARATOR_PARAGRAPH);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_INIT_BIG_TEXT)) {
							// MARCA DE INICIO DE TEXTO EN GRANDE
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_PREFFIX_BIG_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_PREFFIX_BIG_TEXT);
							currentLineLength /= Constants.DIFF_BIG_TEXT;
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_FINISH_BIG_TEXT)) {
							// MARCA DE FIN DE TEXTO EN GRANDE
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_SUFFIX_BIG_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_SUFFIX_BIG_TEXT);
							bResetLineLength = true;
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_INIT_SMALL_TEXT)) {
							// MARCA DE INICIO DE TEXTO EN PEQUE�O
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_PREFFIX_SMALL_TEXT);
							currentLineLength /= Constants.DIFF_SMALL_TEXT;
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_FINISH_SMALL_TEXT)) {
							// MARCA DE FIN DE TEXTO EN PEQUE�O
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_SUFFIX_SMALL_TEXT);
							bResetLineLength = true;	
						} else if (sCurrentLine
								.substring(0, nCurrentIndex)
								.equals(
										Constants.MARK_NO_NEED_USER_PULSE_PLEASE)) {
							// MARCA DE USUARIO, NO NECESITAS PULSAR PARA
							// AVANZAR EL TEXTO
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE)
									: Constants.config_wii
											.get(Constants.SYMBOL_NO_NEED_USER_PULSE_PLEASE);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_OPTION_TEXT_QUESTION)) {
							// MARCA DE PREGUNTA EN TEXTO DE OPCIONES
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_OPTION_TEXT_QUESTION)
									: Constants.config_wii
											.get(Constants.SYMBOL_OPTION_TEXT_QUESTION);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_OPTION_TEXT_DEFAULT)) {
							// MARCA DE OPCI�N POR DEFECTO EN TEXTO DE OPCIONES
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_OPTION_TEXT_DEFAULT)
									: Constants.config_wii
											.get(Constants.SYMBOL_OPTION_TEXT_DEFAULT);
						} else if (sCurrentLine.substring(0, nCurrentIndex)
								.equals(Constants.MARK_OPTION_TEXT)) {
							// MARCA DE OPCI�N EN TEXTO DE OPCIONES
							sTranslateText += (sPlatform.equals("PS2")) ? Constants.config_ps2
									.get(Constants.SYMBOL_OPTION_TEXT)
									: Constants.config_wii
											.get(Constants.SYMBOL_OPTION_TEXT);
						}
						sCurrentLine = sCurrentLine.substring(nCurrentIndex);
					}
					if (nTotalTextLength > currentLineLength) {
						sErrorDescription = "El tama�o del texto legible no puede ser superior a "
								+ Constants.N_LINE_LENGTH_DEFAULT;
					}
					if(bResetLineLength) {
						currentLineLength = Constants.N_LINE_LENGTH_DEFAULT;
						bResetLineLength = false;
					}
				}
				if (sErrorDescription != null) {
					System.err.println("ERROR: Linea " + nLine + ": "
							+ sErrorDescription);
					bCorrectGeneration = false;
				} else {
					for (int nChar = 0; nChar < sTranslateText.length(); nChar++) {
						fosTranslate.write(sTranslateText.charAt(nChar));
					}
				}
			}

		} catch (Exception e) {
			System.err.println("Problemas en la l�nea:" + nLine + " - "
					+ sCurrentLine);
			e.printStackTrace();
		} finally {
			try {
				if (fosTranslate != null)
					fosTranslate.close();
				if (brIntermediate != null)
					brIntermediate.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
		return bCorrectGeneration;
	}
}